import { dawayaIndexItemToCommercialProduct, ensureDawayaDatabaseLoaded, findDawayaIndexItemSync, isPureGenericIngredientQuery } from './dawayaDrugDatabaseService';

// ── Rate Limiting & Anti-Flood Security Guard ──
const AI_CALL_HISTORY: number[] = [];
const MAX_CALLS_PER_MINUTE = 20;
const MIN_GAP_BETWEEN_CALLS_MS = 800;
let lastCallTimestamp = 0;

export function checkAiRateLimit(): { allowed: boolean; waitSec: number } {
  const now = Date.now();
  // Clean calls older than 60 seconds
  while (AI_CALL_HISTORY.length > 0 && now - AI_CALL_HISTORY[0] > 60000) {
    AI_CALL_HISTORY.shift();
  }

  // Minimum gap between rapid-fire clicks
  if (now - lastCallTimestamp < MIN_GAP_BETWEEN_CALLS_MS) {
    return { allowed: false, waitSec: 1 };
  }

  if (AI_CALL_HISTORY.length >= MAX_CALLS_PER_MINUTE) {
    const oldest = AI_CALL_HISTORY[0];
    const waitSec = Math.ceil((60000 - (now - oldest)) / 1000);
    return { allowed: false, waitSec: Math.max(1, waitSec) };
  }

  lastCallTimestamp = now;
  AI_CALL_HISTORY.push(now);
  return { allowed: true, waitSec: 0 };
}

import type { Lang } from './types';
import { getCurrentEmergencyInfo } from './emergencyLocation';
// geminiApi.ts - Multi-Engine Bilingual AI Vision, Deterministic Prescription OCR & Clinical Assistant

import {
  ACTIVE_INGREDIENTS,
  EGYPTIAN_COMMERCIAL_PRODUCTS,
  EgyptianCommercialProduct,
} from './egyptianDrugDatabase';

import { db, configured as firebaseConfigured } from './firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';

// Section 7 Security Fix: Private AI provider keys are NEVER bundled in VITE_ variables,
// localStorage, or client-readable Firestore documents. All AI requests go through the
// authenticated server-side proxy (/api/ai/generate) or deterministic clinical fallback.
let serverAiProxyReady = false;
let proxyCheckComplete = false;
export let lastAiVisionDiagnostic = '';
export let lastAiRawOutputPreview = '';

const DEFAULT_CLOUD_AI_PROXY_URL = 'https://dawaya.pages.dev';

// Ignore legacy undeployed cloudfunctions.net placeholder from old CI env vars; use same-origin on dawaya.pages.dev or https://dawaya.pages.dev
const RAW_ENV_PROXY_URL =
  typeof import.meta !== 'undefined' && import.meta.env?.VITE_AI_PROXY_BASE_URL
    ? String(import.meta.env.VITE_AI_PROXY_BASE_URL).replace(/\/+$/, '')
    : '';

const AI_PROXY_BASE_URL =
  RAW_ENV_PROXY_URL && !RAW_ENV_PROXY_URL.includes('cloudfunctions.net')
    ? RAW_ENV_PROXY_URL
    : typeof window !== 'undefined' && window.location?.hostname?.includes('dawaya.pages.dev')
      ? ''
      : DEFAULT_CLOUD_AI_PROXY_URL;

export function sanitizePatientPiiForAi(rawText: string): string {
  return (rawText || '')
    // 1. Egyptian 14-digit National ID (both Western & Arabic-Indic digits)
    .replace(/\b[0-9\u0660-\u0669]{14}\b/g, '[REDACTED_ID]')
    // 2. Egyptian mobile & landline phone numbers (Western & Arabic-Indic digits)
    .replace(/\b(?:\+?20|0)?1[0125][0-9\u0660-\u0669]{8}\b/g, '[REDACTED_PHONE]')
    .replace(/\b0[2-9][0-9\u0660-\u0669]{7,8}\b/g, '[REDACTED_LANDLINE]')
    // 3. Email addresses
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[REDACTED_EMAIL]')
    // 4. Passport, Syndicate, or Medical Record Numbers (e.g., A12345678, MRN-12345)
    .replace(/\b(?:[A-Z]\d{7,9}|MRN[-_]?\d{4,12})\b/gi, '[REDACTED_RECORD_NO]')
    // 5. Credit/Debit Card numbers (13-16 digits)
    .replace(/\b(?:\d[ -]*?){13,16}\b/g, '[REDACTED_CARD]')
    // 6. Explicit Patient Name / Address labels in Arabic & English
    .replace(/(?:اسم المريض|المريض|الاسم الرباعي|الاسم الثلاثي|Patient Name|Name)\s*[:：-]\s*[^\n،,.]{2,40}/gi, '[REDACTED_PATIENT_NAME]')
    .replace(/(?:العنوان بالتفصيل|العنوان|محل الإقامة|Address)\s*[:：-]\s*[^\n،,.]{4,70}/gi, '[REDACTED_ADDRESS]')
    // 7. GPS coordinates (lat, lng)
    .replace(/\b-?\d{1,2}\.\d{4,8}\s*,\s*-?\d{1,3}\.\d{4,8}\b/g, '[REDACTED_COORDS]');
}

export async function loadSharedCloudAiKey(): Promise<string> {
  if (typeof window !== 'undefined') {
    try {
      localStorage.removeItem('gemini_api_key');
    } catch {
      /* ignore */
    }
  }
  if (proxyCheckComplete && serverAiProxyReady) return '';
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 6000);
  try {
    const resp = await fetch(`${AI_PROXY_BASE_URL}/api/ai/status`, {
      method: 'GET',
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    if (resp.ok) {
      const data = await resp.json();
      serverAiProxyReady = Boolean(data?.configured);
      if (!serverAiProxyReady) lastAiVisionDiagnostic = 'CLOUDFLARE_KEY_MISSING';
      if (serverAiProxyReady) proxyCheckComplete = true;
    }
  } catch {
    clearTimeout(timer);
    serverAiProxyReady = false;
  }
  return '';
}

if (typeof window !== 'undefined') {
  loadSharedCloudAiKey().catch(() => {});
}

let cachedAdminVisionKey = '';
let cachedClientModels: string[] | null = null;

async function resolveAdminVisionKey(): Promise<string> {
  if (cachedAdminVisionKey) return cachedAdminVisionKey;
  if (typeof window !== 'undefined') {
    try {
      const localCfg = JSON.parse(localStorage.getItem('dawaya_ai_config_v1') || 'null');
      if (localCfg?.visionApiKey && String(localCfg.visionApiKey).trim().length > 15) {
        cachedAdminVisionKey = String(localCfg.visionApiKey).trim();
        return cachedAdminVisionKey;
      }
    } catch {}
  }
  if (firebaseConfigured && db) {
    try {
      const pubSnap = await getDoc(doc(db, 'systemSettings', 'ai_runtime'));
      if (pubSnap.exists() && pubSnap.data()?.visionApiKey) {
        cachedAdminVisionKey = String(pubSnap.data().visionApiKey).trim();
        return cachedAdminVisionKey;
      }
    } catch {}
    try {
      const snap = await getDoc(doc(db, 'system_config', 'ai_settings'));
      if (snap.exists() && snap.data()?.visionApiKey) {
        cachedAdminVisionKey = String(snap.data().visionApiKey).trim();
        return cachedAdminVisionKey;
      }
    } catch {}
  }
  return '';
}

async function callDirectAdminKeyFallback(params: {
  sanitizedPrompt: string;
  inlineImageBase64?: string;
  mimeType?: string;
  inlineAudioBase64?: string;
  audioMimeType?: string;
}): Promise<string> {
  const visionKey = await resolveAdminVisionKey();
  if (!visionKey) return '';

  // Support Groq key (gsk_...) if configured in Admin Panel
  if (visionKey.startsWith('gsk_')) {
    const hasImage = Boolean(params.inlineImageBase64);
    const models = hasImage
      ? ['meta-llama/llama-4-scout-17b-16e-instruct', 'meta-llama/llama-4-maverick-17b-128e-instruct']
      : ['llama-3.3-70b-versatile', 'meta-llama/llama-4-scout-17b-16e-instruct'];
    for (const m of models) {
      try {
        const content = hasImage
          ? [
              { type: 'text', text: params.sanitizedPrompt },
              {
                type: 'image_url',
                image_url: { url: `data:${params.mimeType || 'image/jpeg'};base64,${params.inlineImageBase64}` },
              },
            ]
          : params.sanitizedPrompt;
        const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${visionKey}` },
          body: JSON.stringify({ model: m, messages: [{ role: 'user', content }], temperature: 0.15, max_completion_tokens: 1800 }),
        });
        if (r.ok) {
          const d = await r.json();
          const txt = d?.choices?.[0]?.message?.content || '';
          if (txt && String(txt).trim()) return String(txt).trim();
        }
      } catch {}
    }
    return '';
  }

  // Google Gemini API key (AIza...) with live model discovery & non-thought part extraction
  if (!cachedClientModels) {
    try {
      const mRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models`, {
        headers: { 'x-goog-api-key': visionKey },
      });
      if (mRes.ok) {
        const mData = await mRes.json();
        const list = Array.isArray(mData?.models) ? mData.models : [];
        const usable = list
          .filter((x: any) => Array.isArray(x?.supportedGenerationMethods) && x.supportedGenerationMethods.includes('generateContent'))
          .map((x: any) => String(x.name || '').replace(/^models\//, ''))
          .filter((id: string) => id && !/(embedding|imagen|veo|tts|audio|aqa|bisect|robotics)/i.test(id));
        if (usable.length > 0) cachedClientModels = usable;
      }
    } catch {}
  }

  const candidateModels = Array.from(
    new Set([
      'gemini-2.5-flash',
      'gemini-2.5-flash-lite',
      ...(cachedClientModels || []),
      'gemini-1.5-flash',
      'gemma-3-27b-it',
    ])
  ).slice(0, 6);

  const parts: Array<Record<string, unknown>> = [{ text: params.sanitizedPrompt }];
  if (params.inlineImageBase64) {
    parts.push({
      inline_data: {
        mime_type: params.mimeType || 'image/jpeg',
        data: params.inlineImageBase64,
      },
    });
  }
  if (params.inlineAudioBase64) {
    parts.push({
      inline_data: {
        mime_type: params.audioMimeType || 'audio/webm',
        data: params.inlineAudioBase64,
      },
    });
  }

  for (const modelId of candidateModels) {
    try {
      const gUrl = `https://generativelanguage.googleapis.com/v1beta/models/${modelId}:generateContent`;
      const gRes = await fetch(gUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': visionKey },
        body: JSON.stringify({
          contents: [{ parts }],
          generationConfig: { temperature: 0.15, maxOutputTokens: 2500 },
        }),
      });
      if (!gRes.ok) continue;
      const gData = await gRes.json();
      const rawParts = gData?.candidates?.[0]?.content?.parts || [];
      const nonThought = rawParts.filter((p: any) => !p?.thought && typeof p?.text === 'string');
      const outText = (nonThought.length > 0 ? nonThought : rawParts)
        .map((p: any) => p?.text || '')
        .join('\n')
        .trim();
      if (outText) {
        lastAiVisionDiagnostic = `OK:${modelId}`;
        lastAiRawOutputPreview = outText.slice(0, 600);
        return outText;
      }
    } catch {}
  }
  return '';
}

export async function callServerAiProxy(params: {
  prompt: string;
  inlineImageBase64?: string;
  mimeType?: string;
  inlineAudioBase64?: string;
  audioMimeType?: string;
  model?: string;
}): Promise<string> {
  const sanitizedPrompt = sanitizePatientPiiForAi(params.prompt).slice(0, 12000);
  if (!serverAiProxyReady) {
    await loadSharedCloudAiKey();
  }
  if (serverAiProxyReady) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 28000);
    try {
      const { auth } = await import('./firebase');
      const token = auth?.currentUser ? await auth.currentUser.getIdToken().catch(() => '') : '';
      const resp = await fetch(`${AI_PROXY_BASE_URL}/api/ai/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        signal: ctrl.signal,
        body: JSON.stringify({
          prompt: sanitizedPrompt,
          inlineImageBase64: params.inlineImageBase64,
          mimeType: params.mimeType,
          inlineAudioBase64: params.inlineAudioBase64,
          audioMimeType: params.audioMimeType,
          model: params.model === 'gemini-2.0-flash' ? 'gemini-2.0-flash' : 'gemini-2.5-flash',
        }),
      });
      clearTimeout(timer);
      if (resp.ok) {
        const data = await resp.json();
        const out = typeof data?.text === 'string' ? data.text.trim() : '';
        if (out) {
          lastAiVisionDiagnostic = `OK:${data?.model || 'gemini'}`;
          lastAiRawOutputPreview = out.slice(0, 600);
          return out;
        }
        lastAiVisionDiagnostic = `EMPTY_MODEL_TEXT:${data?.model || ''}`;
      } else {
        const errBody = await resp.text().catch(() => '');
        lastAiVisionDiagnostic = `HTTP_${resp.status}:${errBody.slice(0, 120)}`;
      }
    } catch {
      clearTimeout(timer);
    }
  }

  // Always try Admin-configured key fallback if proxy was unconfigured or returned empty/error
  return await callDirectAdminKeyFallback({
    sanitizedPrompt,
    inlineImageBase64: params.inlineImageBase64,
    mimeType: params.mimeType,
    inlineAudioBase64: params.inlineAudioBase64,
    audioMimeType: params.audioMimeType,
  });
}

export function getApiKey(): string {
  return '';
}

export function hasApiKey(): boolean {
  return true;
}

export function setApiKey(_key: string): void {
  if (typeof window !== 'undefined') {
    try {
      localStorage.removeItem('gemini_api_key');
    } catch {
      /* ignore */
    }
  }
}

export function clearApiKey(): void {
  if (typeof window !== 'undefined') {
    try {
      localStorage.removeItem('gemini_api_key');
    } catch {
      /* ignore */
    }
  }
}

export function isCustomApiKey(): boolean {
  return serverAiProxyReady;
}

/**
 * Cleans any raw LLM Markdown (tables, **, ###, ---, < >) into crisp, readable,
 * well-spaced medical text with clean bullet points and numbered sections.
 */
export function cleanAssistantMarkdown(raw: string): string {
  if (!raw) return '';
  let preservedActionTag = '';
  let workingRaw = raw
    .replace(/<think>[\s\S]*?<\/think>/gi, '')
    .replace(/<\/?think>/gi, '')
    .trim();
  const actionMatch = workingRaw.match(/\[\[ACTION_CALL:\s*\{[\s\S]*?\}\s*\]\]/i);
  if (actionMatch) {
    preservedActionTag = actionMatch[0];
    workingRaw = workingRaw.replace(actionMatch[0], '').trim();
  }

  const preSplit = workingRaw
    .replace(/\|\s*\|/g, '\n|')
    .replace(/\s*#{2,6}\s*/g, '\n### ')
    .replace(/\s*---+\s*/g, '\n')
    .replace(/\s+-\s+(?=\*\*)/g, '\n• ')
    .replace(/\s+(?=\d+\.\s)/g, '\n');
  const lines = preSplit.split(/\r?\n/);
  const cleanedLines: string[] = [];

  for (const line of lines) {
    let s = line.trim();
    if (!s) {
      if (cleanedLines.length > 0 && cleanedLines[cleanedLines.length - 1] !== '') {
        cleanedLines.push('');
      }
      continue;
    }

    if (/^[-=_*|:\s]+$/.test(s)) {
      continue;
    }

    if (s.includes('|')) {
      const cells = s
        .split('|')
        .map((c) => c.replace(/\*\*/g, '').replace(/[<>*#`_]/g, '').trim())
        .filter(Boolean);
      if (cells.length === 0) continue;
      if (
        cells.some(
          (c) =>
            c === 'نوع العدوى' ||
            c === 'الاسم العلمي' ||
            c === 'طريقة العمل المختصرة' ||
            c.toLowerCase() === 'first-line'
        ) &&
        cells.length >= 3
      ) {
        continue;
      }
      s = '• ' + cells.join(' — ');
    }

    if (/^#{1,6}\s+/.test(s)) {
      s = s.replace(/^#{1,6}\s+/, '').trim();
      if (cleanedLines.length > 0 && cleanedLines[cleanedLines.length - 1] !== '') {
        cleanedLines.push('');
      }
      if (!s.endsWith(':')) s += ':';
    }

    s = s
      .replace(/\*\*/g, '')
      .replace(/__/g, '')
      .replace(/`/g, '')
      .replace(/<\s*>/g, '')
      .replace(/[<>]/g, '')
      .trim();

    s = s.replace(/^[-*]\s+/, '• ');

    s = s
      .replace(/\s+(?=\d+\.\s)/g, '\n')
      .replace(/\s+(?=•\s)/g, '\n')
      .replace(/\s+(?=⚠️)/g, '\n\n');

    for (const sub of s.split('\n')) {
      const trimmedSub = sub.trim();
      if (trimmedSub) {
        cleanedLines.push(trimmedSub);
      }
    }
  }

  const finalClean = cleanedLines.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  return preservedActionTag ? `${finalClean}\n${preservedActionTag}` : finalClean;
}

export const SYSTEM_PROMPT = `أنت الطبيب والاستشاري الصيدلاني الذكي الشامل والناطق (DAWAYA Senior Clinical AI Doctor & Pharmacist) لمنصة «دوايا | DAWAYA» الرائدة في مصر والعالم العربي.
لديك وصول كامل وخبرة سريرية عميقة تشمل:
1. موسوعة الأدوية المصرية الشاملة (أكثر من 26,562 دواء رسمي بالأسعار والبدائل المتكافئة حيوياً والتحذيرات السبعة).
2. مجمع الـ 20 عيادة تخصصية الذكية ومشخص الأعراض البصري باللمس على خريطة جسم الإنسان (/body-map).
3. فاحص تعارضات الأكل والشرب المصرية مع الأدوية (الشاي، القهوة، اللبن، العرقسوس، الملوخية، الجريب فروت) على (/food-drug-checker).
4. مُولّد وجبات الأمراض المزمنة (السكر والضغط والكلى والدهون والنقرس) على (/meal-planner).
5. نظام التذكير الذكي بمواعيد الجرعات وحبوب منع الحمل اليومية، ومحاكي الأثر البصري للأدوية داخل الأعضاء (/organ-simulator).
6. الماسح الذكي لورق التحاليل والروشتات بالكاميرا والمؤشرات الملونة (/lab-photo-scanner).

قواعد شخصيتك وطريقتك الذهبية في التعامل مع المرضى:
1. **الترحيب الودود باللهجة المصرية العامية الأصيلة:**
   تحدث دايماً كطبيب واستشاري مصري شاطر، ودود، إنساني، وصبور جداً ("ألف سلامة عليك يا فندم"، "بص يا سيدي"، "من عنيا الاتنين"، "متقلقش خالص"، "طمني عليك"). لو سألك المريض بأي لغة ثانية (إنجليزي، فرنسي، ألماني، إسباني) أجب بطلاقة بنفس لغته.
2. **انفتاح كامل على كل المواضيع مع احترام تام وبدون شتايم نهائياً:**
   أنت مساعد ذكي ومنفتح تجيب على كل الأسئلة في أي مجال (الطبية، الأدوية، التحاليل، العناية بالبشرة، التغذية، التقنية، التعليم، أو الأسئلة الحياتية العامة والثقافية) بحرية وذكاء وود باللهجة المصرية، لكن يُمنع منعاً باتاً استخدام أي شتائم أو سباب أو ألفاظ نابية أو إهانات تحت أي ظرف حتى لو كان كلام المستخدم مستفزاً؛ حافظ دايماً على أسلوب راقٍ ومحترم.
3. **الدقة السريرية والأمان الصارم (Triple Check):**
   - فحص تعارضات الأدوية مع الحساسية المسجلة للمريض في ملفه الصحي.
   - التحذير الصارم من «الضربة الثلاثية للكلى» (مسكن NSAID + دواء ضغط + مدر بول).
   - التحذير القاطع من «حقنة البرد 3×1» الشعبية وتوضيح خطر الكورتيزون والمضاد العشوائي.
   - التحذير من العرقسوس والفوارات لمرضى الضغط، ومنع المقليات ومسكنات NSAID على معدة فارغة.
   - في الطوارئ الحرجة (اشتباه جلطة مخ FAST، ألم ضاغط بالصدر، ضيق تنفس حاد، تسمم)، قدم الإسعاف الأولي فوراً ووجه للاتصال بالإسعاف 123.
4. **التوجيه العملي الذكي لأقسام المنصة:**
   في نهاية إجابتك، وجّه المريض بأسلوب لطيف للأداة أو العيادة المجهزة لمساعدته مجاناً في الموقع (مثال: "تقدر كمان تفتح خريطة الجسم وتضغط على مكان الوجع"، أو "تقدر تفحص تعارضات أكلك مع الدواء في فاحص الأكل والشرب").
5. **تنفيذ الأوامر المباشرة في حساب المريض (Action Calling):**
   إذا طلب المريض تسجيل دواء أو حساسية أو ضبط تذكير أو فحص ملفه، اكتب الرد الطبي اللطيف، ثم ضع في السطر الأخير كود الإجراء [[ACTION_CALL: ...]].`;;

export const COMPACT_CLOUD_SYSTEM_PROMPT = `أنت مساعد ذكي شامل ومتصل بالإنترنت (Live Web & Health AI Assistant).
قواعد هامة جداً:
1. جاوب على سؤال المستخدم فوراً وبدقة ومباشرة باللهجة المصرية الودودة ("يا هلا بيك"، "بص يا سيدي"، "من عنيا").
2. لو مرفق مع السؤال [بيانات حية ومباشرة من الإنترنت الآن]، اعتمد عليها في إجابتك (مثل مواعيد ونتائج المباريات اليوم، الطقس، أسعار العملات، والأخبار الجارية).
3. جاوب على قد السؤال بالظبط في صلب الموضوع، وإياك ترد بردود عامة أو تتكلم عن موضوع مختلف عن سؤال المستخدم.
4. رتب الإجابة في نقاط واضحة بدون جداول Markdown (|) وبدون نجوم ** أو علامات ###.
5. أجب على جميع الأسئلة بانفتاح وود، وامنع تماماً أي شتائم أو ألفاظ خارجة أو مسيئة.`;

function isValidCloudReply(text: string | undefined | null): boolean {
  if (!text) return false;
  const t = text
    .replace(/<think>[\s\S]*?<\/think>/gi, '')
    .trim();
  if (t.length < 4) return false;
  if (
    /^(<!DOCTYPE|<html|<head|\{"error"|502 Bad Gateway|504 Gateway|429 Too Many|Error:|Rate limit|Internal Server Error|Notice:|IMPORTANT NOTICE)/i.test(
      t
    )
  ) {
    return false;
  }
  return true;
}

async function gtxTranslate(text: string, sl: string, tl: string): Promise<string> {
  if (!text || !text.trim()) return '';
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 3500);
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sl}&tl=${tl}&dt=t&q=${encodeURIComponent(
      text.slice(0, 1200)
    )}`;
    const res = await fetch(url, { signal: ctrl.signal });
    clearTimeout(timer);
    if (!res.ok) return text;
    const data = await res.json();
    if (Array.isArray(data?.[0])) {
      return data[0].map((seg: unknown[]) => (typeof seg?.[0] === 'string' ? seg[0] : '')).join('');
    }
  } catch {
    clearTimeout(timer);
  }
  return text;
}

/**
 * Calls an OpenAI-compatible `/chat/completions` endpoint directly first,
 * and if the browser blocks it due to CORS (`TypeError`), retries automatically via `removed-legacy-endpoint`!
 */
async function callOpenAiCompatibleEndpoint(_params: {
  url: string;
  model: string;
  messages: Array<{ role: string; content: string }>;
  apiKey?: string;
  timeoutMs?: number;
}): Promise<string | null> {
  // Section 6 Security Fix: Disabled direct browser calls to third-party AI gateways and public CORS proxy relays.
  return null;
}

async function fetchLiveGoogleNewsSnippets(_query: string, _maxAgeDays = 30): Promise<string[]> {
  // Section 6 Security Fix: Disabled public CORS relays (rss2json / allorigins).
  return [];
}

interface FootballTeamMapping {
  nameAr: string;
  nameEn: string;
  espnId?: string;
  espnLeague?: string;
  patterns: RegExp;
}

const FOOTBALL_TEAMS: FootballTeamMapping[] = [
  {
    nameAr: 'ريال مدريد',
    nameEn: 'Real Madrid',
    espnId: '86',
    espnLeague: 'esp.1',
    patterns: /(ريال مدريد|الريال|ملكي|ميرينجي|real madrid)/i,
  },
  {
    nameAr: 'برشلونة',
    nameEn: 'Barcelona',
    espnId: '83',
    espnLeague: 'esp.1',
    patterns: /(برشلونه|برشلونة|البارسا|البرسا|كتالوني|barcelona|barca)/i,
  },
  {
    nameAr: 'الأهلي المصري',
    nameEn: 'Al Ahly',
    patterns: /(الاهلي|الأهلي|اهلي|أهلي|al ahly)/i,
  },
  {
    nameAr: 'الزمالك',
    nameEn: 'Zamalek',
    patterns: /(الزمالك|زمالك|zamalek)/i,
  },
  {
    nameAr: 'ليفربول',
    nameEn: 'Liverpool',
    espnId: '364',
    espnLeague: 'eng.1',
    patterns: /(ليفربول|ليفر|الريدز|ماتش صلاح|ماتش محمد صلاح|liverpool)/i,
  },
  {
    nameAr: 'مانشستر سيتي',
    nameEn: 'Manchester City',
    espnId: '382',
    espnLeague: 'eng.1',
    patterns: /(مانشستر سيتي|السيتي|مان سيتي|ماتش مرموش|manchester city|man city)/i,
  },
  {
    nameAr: 'أرسنال',
    nameEn: 'Arsenal',
    espnId: '359',
    espnLeague: 'eng.1',
    patterns: /(ارسنال|أرسنال|الجانرز|arsenal)/i,
  },
  {
    nameAr: 'تشيلسي',
    nameEn: 'Chelsea',
    espnId: '363',
    espnLeague: 'eng.1',
    patterns: /(تشيلسي|البلوز|chelsea)/i,
  },
  {
    nameAr: 'مانشستر يونايتد',
    nameEn: 'Manchester United',
    espnId: '360',
    espnLeague: 'eng.1',
    patterns: /(مانشستر يونايتد|اليونايتد|مان يونايتد|manchester united|man utd)/i,
  },
  {
    nameAr: 'بايرن ميونخ',
    nameEn: 'Bayern Munich',
    espnId: '132',
    espnLeague: 'ger.1',
    patterns: /(بايرن|بايرن ميونخ|البافاري|bayern)/i,
  },
  {
    nameAr: 'باريس سان جيرمان',
    nameEn: 'Paris Saint-Germain',
    espnId: '160',
    espnLeague: 'fra.1',
    patterns: /(باريس سان جيرمان|باريس|بي اس جي|\bpsg\b)/i,
  },
  {
    nameAr: 'إنتر ميلان',
    nameEn: 'Inter Milan',
    espnId: '110',
    espnLeague: 'ita.1',
    patterns: /(انتر ميلان|إنتر ميلان|الانتر|الإنتر|\binter milan\b)/i,
  },
  {
    nameAr: 'إي سي ميلان',
    nameEn: 'AC Milan',
    espnId: '103',
    espnLeague: 'ita.1',
    patterns: /(اي سي ميلان|ميلان|\bac milan\b)/i,
  },
  {
    nameAr: 'يوفنتوس',
    nameEn: 'Juventus',
    espnId: '111',
    espnLeague: 'ita.1',
    patterns: /(يوفنتوس|اليوفي|juventus)/i,
  },
  {
    nameAr: 'أتلتيكو مدريد',
    nameEn: 'Atletico Madrid',
    espnId: '1068',
    espnLeague: 'esp.1',
    patterns: /(اتلتيكو|أتلتيكو|atletico)/i,
  },
  {
    nameAr: 'منتخب مصر',
    nameEn: 'Egypt',
    espnId: '656',
    patterns: /(منتخب مصر|المنتخب المصري|ماتش مصر|مباراه مصر|مباراة مصر)/i,
  },
];

function formatCairoDateTime(isoDateStr: string): { dateAr: string; timeAr: string; relativeAr: string } {
  const dt = new Date(isoDateStr);
  if (Number.isNaN(dt.getTime())) {
    return { dateAr: isoDateStr, timeAr: '', relativeAr: '' };
  }
  const dateAr = dt.toLocaleDateString('ar-EG', {
    timeZone: 'Africa/Cairo',
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const timeAr = dt.toLocaleTimeString('ar-EG', {
    timeZone: 'Africa/Cairo',
    hour: '2-digit',
    minute: '2-digit',
  });

  const now = new Date();
  const diffMs = dt.getTime() - now.getTime();
  const diffHours = Math.round(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  let relativeAr = '';
  if (diffMs > 0) {
    if (diffHours < 24) relativeAr = `(خلال ${diffHours} ساعة من الآن 🔥)`;
    else if (diffDays === 1) relativeAr = '(غداً إن شاء الله 🔥)';
    else if (diffDays > 1 && diffDays <= 14) relativeAr = `(بعد ${diffDays} أيام)`;
  } else if (diffMs > -3 * 60 * 60 * 1000) {
    relativeAr = '(جارية الآن / اليوم 🔴)';
  }
  return { dateAr, timeAr, relativeAr };
}

/**
 * Fetches Today's Live Scoreboard across major leagues OR a specific team's upcoming & last match!
 */
async function fetchLiveFootballData(rawQuestion: string): Promise<string | null> {
  const q = rawQuestion.trim();
  const isTodayMatchesQuery =
    /(مين هيلعب|مين بيلعب|مين يلعب|مين اللي هيلعب|في ماتشات ايه|فيه ماتشات ايه|ماتشات النهارده|ماتشات النهاردة|ماتشات انهارده|ماتشات انهاردة|ماتشات اليوم|مباريات اليوم|مباريات النهارده|مباريات انهارده|جدول ماتشات|جدول مباريات)/i.test(
      q
    );
  const isMatchQuery =
    isTodayMatchesQuery ||
    /(ماتش|ماتشات|مباراه|مباراة|مباريات|هيلعب امتي|يلعب امتي|الجاي امتي|القادمه|القادمة|نتيجه|نتيجة|خلص كام|\bnext match\b|\bmatch\b|\bscore\b)/i.test(
      q
    );
  const matchedTeam = FOOTBALL_TEAMS.find((t) => t.patterns.test(q));
  if (!isMatchQuery && !matchedTeam) return null;

  const infoParts: string[] = [];

  // CASE A: User asks "مين هيلعب انهارده يعني" / "ماتشات النهاردة إيه" (without naming a single team)
  if (isTodayMatchesQuery && !matchedTeam) {
    try {
      const leagues = [
        { code: 'uefa.champions', labelAr: 'دوري أبطال أوروبا' },
        { code: 'uefa.europa', labelAr: 'الدوري الأوروبي' },
        { code: 'eng.1', labelAr: 'الدوري الإنجليزي' },
        { code: 'esp.1', labelAr: 'الدوري الإسباني' },
        { code: 'ita.1', labelAr: 'الدوري الإيطالي' },
        { code: 'ger.1', labelAr: 'الدوري الألماني' },
        { code: 'fra.1', labelAr: 'الدوري الفرنسي' },
        { code: 'ksa.1', labelAr: 'الدوري السعودي' },
        { code: 'caf.champions', labelAr: 'دوري أبطال أفريقيا' },
      ];
      const resultsWithLeague = await Promise.allSettled(
        leagues.map(async (lg) => {
          const ctrl = new AbortController();
          const timer = setTimeout(() => ctrl.abort(), 4000);
          const res = await fetch(
            `https://site.api.espn.com/apis/site/v2/sports/soccer/${lg.code}/scoreboard`,
            { signal: ctrl.signal }
          );
          clearTimeout(timer);
          if (!res.ok) return [];
          const data = await res.json();
          const events: any[] = Array.isArray(data?.events) ? data.events : [];
          return events.slice(0, 5).map((ev) => {
            const { timeAr } = formatCairoDateTime(ev.date);
            const comp = ev.competitions?.[0];
            const c1 = comp?.competitors?.[0];
            const c2 = comp?.competitors?.[1];
            const state = ev.status?.type?.state; // 'pre', 'in', 'post'
            const matchLine =
              c1 && c2
                ? state === 'pre'
                  ? `${c1.team?.displayName} ضد ${c2.team?.displayName} — الساعة ${timeAr} بتوقيت مصر`
                  : `${c1.team?.displayName} (${c1.score?.displayValue ?? 0}) - (${c2.score?.displayValue ?? 0}) ${c2.team?.displayName} [${ev.status?.type?.shortDetail || 'انتهت'}]`
                : `${ev.name} — الساعة ${timeAr}`;
            return `• [${lg.labelAr}] ${matchLine}`;
          });
        })
      );

      const allMatchLines: string[] = [];
      for (const r of resultsWithLeague) {
        if (r.status === 'fulfilled' && r.value.length > 0) {
          allMatchLines.push(...r.value);
        }
      }

      if (allMatchLines.length > 0) {
        const translatedMatches = await gtxTranslate(allMatchLines.slice(0, 12).join('\n'), 'en', 'ar');
        infoParts.push(
          `⚽ جدول أبرز مباريات اليوم في الملاعب العالمية (بتوقيت مصر 🇪🇬):\n${translatedMatches}`
        );
      }
    } catch {
      /* continue */
    }

    const todayNews = await fetchLiveGoogleNewsSnippets('مواعيد مباريات اليوم والقنوات الناقلة الدوري المصري', 3);
    if (todayNews.length > 0) {
      infoParts.push(`أبرز عناوين مباريات اليوم في مصر:\n${todayNews.slice(0, 4).join('\n')}`);
    }

    if (infoParts.length > 0) {
      return infoParts.join('\n\n');
    }
  }

  // CASE B: Specific Team Query (e.g., "ماتش الريال الجاي امتي", "ماتش الاهلي الاخير خلص كام")
  if (matchedTeam?.espnId) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 4500);
      const url = `https://site.api.espn.com/apis/site/v2/sports/soccer/${matchedTeam.espnLeague || 'esp.1'}/teams/${matchedTeam.espnId}/schedule`;
      const res = await fetch(url, { signal: ctrl.signal });
      clearTimeout(timer);
      if (res.ok) {
        const data = await res.json();
        const events: Array<Record<string, any>> = Array.isArray(data?.events) ? data.events : [];
        const nowMs = Date.now();
        const upcoming = events
          .filter((e) => new Date(e.date).getTime() >= nowMs - 2 * 60 * 60 * 1000)
          .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
        const past = events
          .filter((e) => new Date(e.date).getTime() < nowMs - 2 * 60 * 60 * 1000)
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

        if (upcoming.length > 0) {
          const nxt = upcoming[0];
          const { dateAr, timeAr, relativeAr } = formatCairoDateTime(nxt.date);
          const matchTitleAr = await gtxTranslate((nxt.name || '').replace(' at ', ' ضد '), 'en', 'ar');
          infoParts.push(
            `• المباراة القادمة لـ ${matchedTeam.nameAr}: ${matchTitleAr} — يوم ${dateAr} ${relativeAr} الساعة ${timeAr} بتوقيت مصر 🇪🇬`
          );
        }
        if (past.length > 0) {
          const lst = past[0];
          const comp = lst.competitions?.[0];
          const c1 = comp?.competitors?.[0];
          const c2 = comp?.competitors?.[1];
          const { dateAr } = formatCairoDateTime(lst.date);
          const scoreStr =
            c1 && c2
              ? `${c1.team?.displayName || ''} (${c1.score?.displayValue ?? ''}) - (${c2.score?.displayValue ?? ''}) ${c2.team?.displayName || ''}`
              : lst.name || '';
          const scoreAr = await gtxTranslate(scoreStr, 'en', 'ar');
          infoParts.push(`• نتيجة آخر مباراة لـ ${matchedTeam.nameAr} (${dateAr}): ${scoreAr} (${scoreStr})`);
        }
      }
    } catch {
      /* continue */
    }
  }

  const sportNewsQuery = matchedTeam
    ? `${matchedTeam.nameAr} نتيجة موعد مباراة`
    : q;
  const newsSnippets = await fetchLiveGoogleNewsSnippets(sportNewsQuery, 14);
  if (newsSnippets.length > 0) {
    infoParts.push(`أحدث الأخبار والنتائج المباشرة:\n${newsSnippets.slice(0, 4).join('\n')}`);
  }

  if (infoParts.length > 0) {
    return infoParts.join('\n\n');
  }
  return null;
}

/**
 * Gathers real-time facts from the internet (Sports, Google News RSS, Weather, Currency, Prayer Times)
 * so the AI LLM can answer with 100% up-to-date live internet information!
 */
async function gatherLiveInternetContext(rawQuestion: string): Promise<{
  directFormattedReply: string | null;
  webContextForAi: string;
}> {
  const q = rawQuestion.trim();
  if (!q) return { directFormattedReply: null, webContextForAi: '' };

  // 1) Football & Match Queries (including "مين هيلعب انهارده يعني")
  if (
    /(مين هيلعب|مين بيلعب|مين يلعب|ماتش|ماتشات|مباراه|مباراة|مباريات|خلص كام|نتيجه ماتش|نتيجة ماتش|الريال|ريال مدريد|برشلونه|برشلونة|الاهلي|الأهلي|الزمالك|ليفربول|مانشستر|سيتي|ارسنال|أرسنال|تشيلسي|بايرن|باريس|انتر|ميلان|يوفنتوس|منتخب مصر|الهلال|النصر|بيراميدز|\bmatch\b|\bscore\b)/i.test(
      q
    )
  ) {
    const footballData = await fetchLiveFootballData(q);
    if (footballData) {
      return {
        directFormattedReply: footballData,
        webContextForAi: `[بيانات المباريات والنتائج الحية من الإنترنت الآن:\n${footballData}]`,
      };
    }
  }

  // 2) Live Weather
  if (/(الطقس|الجو عامل ايه|درجه الحراره|درجة الحرارة|حراره الجو|المطر النهارده|\bweather\b)/i.test(q)) {
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 4500);
      const res = await fetch(
        'https://api.open-meteo.com/v1/forecast?latitude=30.0444&longitude=31.2357&current=temperature_2m,relative_humidity_2m,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min&timezone=Africa%2FCairo',
        { signal: ctrl.signal }
      );
      clearTimeout(t);
      if (res.ok) {
        const data = await res.json();
        const curr = data?.current?.temperature_2m;
        const maxT = data?.daily?.temperature_2m_max?.[0];
        const minT = data?.daily?.temperature_2m_min?.[0];
        const hum = data?.current?.relative_humidity_2m;
        const wind = data?.current?.wind_speed_10m;
        if (curr !== undefined) {
          const wText =
            `حالة الطقس المباشرة الآن في مصر (القاهرة): 🌤️\n` +
            `• درجة الحرارة الحالية: ${curr}° مئوية (العظمى: ${maxT ?? curr}° | الصغرى: ${minT ?? curr}°)\n` +
            `• الرطوبة: ${hum ?? 50}% | سرعة الرياح: ${wind ?? 12} كم/ساعة`;
          return {
            directFormattedReply: wText,
            webContextForAi: `[${wText}]`,
          };
        }
      }
    } catch {
      /* continue */
    }
  }

  // 3) Live Currency Exchange Rates
  if (/(سعر الدولار|الدولار بكام|سعر الريال|الريال بكام|سعر اليورو|اليورو بكام|سعر الدرهم|سعر الدينار|اسعار العملات|أسعار العملات|\bexchange rate\b|\busd to egp\b)/i.test(q)) {
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 4500);
      const res = await fetch('https://open.er-api.com/v6/latest/USD', { signal: ctrl.signal });
      clearTimeout(t);
      if (res.ok) {
        const data = await res.json();
        const egp = data?.rates?.EGP;
        const sar = data?.rates?.SAR;
        const eur = data?.rates?.EUR;
        const aed = data?.rates?.AED;
        const kwd = data?.rates?.KWD;
        if (egp) {
          const cText =
            `أسعار صرف العملات مقابل الجنيه المصري (تحديث مباشر): 💵\n` +
            `• الدولار الأمريكي: ${Number(egp).toFixed(2)} ج.م\n` +
            `• اليورو: ${eur ? (egp / eur).toFixed(2) : '—'} ج.م\n` +
            `• الريال السعودي: ${sar ? (egp / sar).toFixed(2) : '—'} ج.م\n` +
            `• الدرهم الإماراتي: ${aed ? (egp / aed).toFixed(2) : '—'} ج.م\n` +
            `• الدينار الكويتي: ${kwd ? (egp / kwd).toFixed(2) : '—'} ج.م`;
          return {
            directFormattedReply: cText,
            webContextForAi: `[${cText}]`,
          };
        }
      }
    } catch {
      /* continue */
    }
  }

  // 4) Live Prayer Times
  if (/(مواعيد الصلاه|مواعيد الصلاة|مواقيت الصلاه|مواقيت الصلاة|اذان الفجر|أذان الفجر|اذان المغرب|أذان المغرب|اذان الظهر|اذان العصر|اذان العشاء|الصلاه امتي|الصلاة امتى|\bprayer times\b)/i.test(q)) {
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 4500);
      const res = await fetch(
        'https://api.aladhan.com/v1/timingsByCity?city=Cairo&country=Egypt&method=5',
        { signal: ctrl.signal }
      );
      clearTimeout(t);
      if (res.ok) {
        const json = await res.json();
        const timings = json?.data?.timings;
        if (timings) {
          const pText =
            `مواقيت الصلاة اليوم في مصر: 🕌\n` +
            `• الفجر: ${timings.Fajr} | الشروق: ${timings.Sunrise} | الظهر: ${timings.Dhuhr} | العصر: ${timings.Asr} | المغرب: ${timings.Maghrib} | العشاء: ${timings.Isha}`;
          return {
            directFormattedReply: pText,
            webContextForAi: `[${pText}]`,
          };
        }
      }
    } catch {
      /* continue */
    }
  }

  // 5) Current News / Gold Prices
  if (/(اخبار|أخبار|سعر الدهب|سعر الذهب|الدهب بكام|الذهب بكام)/i.test(q)) {
    const news = await fetchLiveGoogleNewsSnippets(q, 7);
    if (news.length > 0) {
      const newsBlock = `أحدث الأخبار المباشرة من الإنترنت اليوم:\n${news.slice(0, 4).join('\n')}`;
      return {
        directFormattedReply: newsBlock,
        webContextForAi: `[${newsBlock}]`,
      };
    }
  }

  return { directFormattedReply: null, webContextForAi: '' };
}

export interface ChatMessage {
  who: 'me' | 'bot';
  text: string;
}

export async function askGemini(
  question: string,
  history: ChatMessage[] = [],
  rawUserQuestion?: string
): Promise<string> {
  // Security: Check Rate Limit & Flood Guard
  const rateLimit = checkAiRateLimit();
  if (!rateLimit.allowed) {
    return (
      '⏳ حفاظاً على أمان واستقرار المنصة وسرعة الخدمة لكل المرضى، يرجى الانتظار ' +
      rateLimit.waitSec +
      ' ثانية قبل إرسال سؤالك التالي.'
    );
  }

  let key = getApiKey();
  if (!key) {
    key = await loadSharedCloudAiKey();
  }
  const emerg = getCurrentEmergencyInfo();
  const dynamicSystemPrompt = SYSTEM_PROMPT.replace(
    'الإسعاف المصري (123)',
    `طوارئ ${emerg.name.ar} (${emerg.number})`
  );

  const cleanUserQ = (
    rawUserQuestion ||
    question.split('\n\n[ملف المريض:')[0] ||
    question
  ).trim();

  // Gather real-time internet data (ESPN Scoreboard, Google News Egypt RSS, Weather, Currency, Prayer)
  const { directFormattedReply, webContextForAi } = await gatherLiveInternetContext(cleanUserQ);

  const questionWithLiveWeb = webContextForAi
    ? `${cleanUserQ}\n\n${webContextForAi}`
    : cleanUserQ;

  const fullPromptForKeyedModels = webContextForAi
    ? `${question}\n\n${webContextForAi}`
    : question;

  // 1) Official DAWAYA Server-Side AI Proxy (Authenticated & PII-Sanitized)
  if (hasApiKey()) {
    const recentHistoryText = history
      .slice(-6)
      .map((m) => `${m.who === 'me' ? 'المريض' : 'المساعد'}: ${(m.text || '').slice(0, 400)}`)
      .join('\n');
    const combinedPrompt = `${dynamicSystemPrompt}\n\n${
      recentHistoryText ? `[سياق المحادثة السابقة:\n${recentHistoryText}]\n\n` : ''
    }${fullPromptForKeyedModels}`;

    for (const geminiModel of ['gemini-2.5-flash', 'gemini-2.0-flash']) {
      const proxyReply = await callServerAiProxy({
        prompt: combinedPrompt,
        model: geminiModel,
      });
      if (isValidCloudReply(proxyReply)) {
        return sanitizeNoProfanity(cleanAssistantMarkdown(proxyReply));
      }
    }
  }

  // 5) If we already fetched verified live internet data (Today's ESPN Matches / Team Schedule / Weather / Currency / Prayer), return it cleanly!
  if (directFormattedReply) {
    return cleanAssistantMarkdown(directFormattedReply);
  }

  throw new Error('ALL_AI_ENDPOINTS_UNAVAILABLE');
}

export function sanitizeNoProfanity(text: string): string {
  const s = String(text || '');
  return s.replace(
    /\b(fuck|shit|bitch|asshole|bastard|dick|pussy|whore|slut|cunt|motherfucker|كسمك|كس امك|ابن الكلب|ابن الوسخة|يا وسخ|يا شرموط|شرموطة|عرص|خول|متناك|منيوك|يلعن دين|قحبة)\b/gi,
    '***'
  );
}

export async function askGeminiWithAudio(
  audioBase64: string,
  audioMimeType: string,
  history: ChatMessage[] = [],
  patientContextPrefix = '',
  lang: Lang = 'ar'
): Promise<{ transcript: string; reply: string }> {
  const rateLimit = checkAiRateLimit();
  if (!rateLimit.allowed) {
    return {
      transcript: '',
      reply:
        '⏳ حفاظاً على أمان واستقرار المنصة، يرجى الانتظار ' +
        rateLimit.waitSec +
        ' ثانية قبل رسالتك الصوتية التالية.',
    };
  }

  let key = getApiKey();
  if (!key) {
    key = await loadSharedCloudAiKey();
  }

  const emerg = getCurrentEmergencyInfo();
  const dynamicSystemPrompt = SYSTEM_PROMPT.replace(
    'الإسعاف المصري (123)',
    `طوارئ ${emerg.name.ar} (${emerg.number})`
  );

  const recentHistoryText = history
    .slice(-5)
    .map((m) => `${m.who === 'me' ? 'المريض' : 'المساعد'}: ${(m.text || '').slice(0, 350)}`)
    .join('\n');

  const audioInstruction =
    lang === 'ar'
      ? `اسمع التسجيل الصوتي المرفق ده كويس جداً، افهم كلام المستخدم بالعامية المصرية أو العربية أو الإنجليزية، واكتب ردك بالصيغة دي بالظبط:
[TRANSCRIPT]: <النص الحرفي اللي قاله المستخدم في الصوت>
[REPLY]: <ردك الطبيعي والمباشر والودود والمحترم بدون أي شتايم على كلامه>

قواعد مهمة:
- لو الصوت مش واضح خالص أو فاضي، اكتب [TRANSCRIPT]: غير واضح و[REPLY]: معلش الصوت مكانش واضح، ممكن تقوله تاني؟
- أجب على أي سؤال في الدنيا بانفتاح واحترام تام وبدون أي ألفاظ خارجة.`
      : `Listen carefully to the attached user voice recording, understand what they said, and respond in this exact format:
[TRANSCRIPT]: <exact words spoken by the user>
[REPLY]: <your helpful, open, respectful direct response without any profanity>`;

  const combinedPrompt = `${dynamicSystemPrompt}\n\n${
    patientContextPrefix ? `${patientContextPrefix}\n\n` : ''
  }${
    recentHistoryText ? `[سياق المحادثة السابقة:\n${recentHistoryText}]\n\n` : ''
  }${audioInstruction}`;

  for (const geminiModel of ['gemini-2.5-flash', 'gemini-2.0-flash']) {
    const raw = await callServerAiProxy({
      prompt: combinedPrompt,
      inlineAudioBase64: audioBase64,
      audioMimeType: audioMimeType || 'audio/webm',
      model: geminiModel,
    });

    if (isValidCloudReply(raw)) {
      const cleaned = sanitizeNoProfanity(cleanAssistantMarkdown(raw));
      const trMatch = cleaned.match(/\[TRANSCRIPT\]\s*:\s*([\s\S]*?)(?=\[REPLY\]\s*:|$)/i);
      const repMatch = cleaned.match(/\[REPLY\]\s*:\s*([\s\S]*)$/i);
      const transcript = trMatch ? trMatch[1].trim() : '';
      const reply = repMatch ? repMatch[1].trim() : cleaned.replace(/\[TRANSCRIPT\]\s*:.*\n?/i, '').trim();
      return {
        transcript: transcript && transcript !== 'غير واضح' ? transcript : '',
        reply: reply || cleaned,
      };
    }
  }

  throw new Error('AUDIO_AI_UNAVAILABLE');
}

export interface VisionAnalysisResult {
  detectedDrugName: string;
  matchedIngredientId: string | null;
  summary: string;
  rawExtractedText: string;
}

const VISION_DRUG_IDS =
  'amoxicillin-clavulanic-acid, amoxicillin, ampicillin-sulbactam, flucloxacillin, penicillin-v-potassium, cephalexin, cefadroxil, cefuroxime, cefixime, cefdinir, ceftriaxone, cefotaxime, cefoperazone-sulbactam, cefepime, azithromycin, clarithromycin, erythromycin, ciprofloxacin, levofloxacin, moxifloxacin, doxycycline, clindamycin, metronidazole, nitrofurantoin, co-trimoxazole, gentamicin, amikacin, meropenem, vancomycin, linezolid, fusidic-acid, rifaximin';

const KNOWN_INGREDIENT_SLUGS = new Set(
  VISION_DRUG_IDS.split(',').map((s) => s.trim().toLowerCase())
);

/**
 * Normalizes Arabic and English text for phonetic & fuzzy matching
 */
export function normalizePharmaText(str: string): string {
  return (str || '')
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .replace(/[^a-z0-9\u0600-\u06FF\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Maps dot-similar Arabic letters to their base skeleton so OCR dot errors
 * (e.g., زيثروماكس vs ريثروماكس / زيتروماكس / يثروماكس) still match accurately
 */
export function normalizeArabicSkeleton(str: string): string {
  return normalizePharmaText(str)
    .replace(/ز/g, 'ر')
    .replace(/ذ/g, 'د')
    .replace(/[ثتن]/g, 'ب')
    .replace(/[جخ]/g, 'ح')
    .replace(/ش/g, 'س')
    .replace(/ض/g, 'ص')
    .replace(/ظ/g, 'ط')
    .replace(/غ/g, 'ع')
    .replace(/ق/g, 'ف');
}

function levenshteinDistance(a: string, b: string): number {
  if (a.length < b.length) {
    const tmp = a;
    a = b;
    b = tmp;
  }
  if (b.length === 0) return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, idx) => idx);
  for (let i = 0; i < a.length; i++) {
    const curr = [i + 1];
    for (let j = 0; j < b.length; j++) {
      const cost = a[i] === b[j] ? 0 : 1;
      curr.push(Math.min(prev[j + 1] + 1, curr[j] + 1, prev[j] + cost));
    }
    prev = curr;
  }
  return prev[b.length];
}

function stringSimilarity(a: string, b: string): number {
  if (!a || !b) return 0;
  const maxLen = Math.max(a.length, b.length);
  if (maxLen === 0) return 1;
  return 1 - levenshteinDistance(a, b) / maxLen;
}

const PHARMA_STOP_WORDS = new Set([
  'tablet', 'tablets', 'tab', 'capsule', 'capsules', 'cap', 'suspension', 'syrup',
  'vial', 'ampoule', 'amp', 'infusion', 'drops', 'cream', 'ointment', 'sachet',
  'oral', 'film', 'coated', 'forte', 'retard', 'pediatric', 'plus', 'acid',
  'potassium', 'sodium', 'trihydrate', 'hydrate', 'hydrochloride', 'sulfate',
  'topical', 'ophthalmic', 'eye', 'ear', 'gel', 'solution', 'powder', 'for',
  'injection', 'iv', 'im', 'sr', 'xl', 'es', 'ds', 'mg', 'gm', 'ml', 'mcg', 'iu',
  'unknown', 'unreadable', 'drug', 'name', 'medicine', 'antibiotic', 'box', 'strip', 'pack',
  'egypt', 'pharma', 'pharmaceuticals', 'company', 'pfizer', 'gsk', 'sanofi', 'novartis',
  'اقراص', 'قرص', 'كبسول', 'كبسولات', 'شراب', 'معلق', 'فيال', 'امبول', 'حقن', 'للحقن',
  'وريدي', 'الوريدي', 'عضلي', 'العضلي', 'نقط', 'قطره', 'كريم', 'مرهم', 'موضعي', 'فوار',
  'اكياس', 'كيس', 'مجم', 'جم', 'مل', 'مغلفه', 'مضاعف', 'القوه', 'للاطفال', 'اطفال',
  'للرضع', 'رضع', 'فمويه', 'فموي', 'كبار', 'حمض', 'تركيز', 'عبوه', 'شريط', 'دواء',
  'مضاد', 'حيوي', 'جل', 'محلول', 'بودره', 'قطرات', 'عين', 'اذن', 'العيون', 'الاذن',
  'بوتاسيوم', 'صوديوم', 'شركه', 'الماده', 'الفعاله', 'روشته', 'طبيب', 'صيدلي',
]);

export const OCR_ALIASES: Array<{
  aliases: string[];
  tradeNameAr: string;
  ingredientId: string;
}> = [
  {
    aliases: ['زيثروماكس', 'ريثروماكس', 'زيتروماكس', 'يثروماكس', 'زيترومكس', 'ريثرومكس', 'zithromax', 'ithromax', 'azithromax'],
    tradeNameAr: 'زيثروماكس 500 مجم أقراص',
    ingredientId: 'azithromycin',
  },
  {
    aliases: ['زيثرون', 'ريثرون', 'xithrone', 'zithron', 'xithron'],
    tradeNameAr: 'زيثرون 500 مجم أقراص',
    ingredientId: 'azithromycin',
  },
  {
    aliases: ['زيثروكان', 'ريثروكان', 'zithrokan', 'zithrocan'],
    tradeNameAr: 'زيثروكان 500 مجم كبسول',
    ingredientId: 'azithromycin',
  },
  {
    aliases: ['ايبيزيثرو', 'ابيزيثرو', 'epizithro'],
    tradeNameAr: 'إيبيزيثرو 500 مجم كبسول',
    ingredientId: 'azithromycin',
  },
  {
    aliases: ['زيسروسين', 'ريسروسين', 'zisrocin'],
    tradeNameAr: 'زيسروسين 500 مجم كبسول',
    ingredientId: 'azithromycin',
  },
  {
    aliases: ['ديلزوسين', 'delzosin'],
    tradeNameAr: 'ديلزوسين 500 مجم كبسول',
    ingredientId: 'azithromycin',
  },
  {
    aliases: ['اوجمنتين', 'اوغمنتين', 'وجمنتين', 'اوحمنتين', 'augmentin', 'ugmentin'],
    tradeNameAr: 'أوجمنتين 1 جم أقراص',
    ingredientId: 'amoxicillin-clavulanic-acid',
  },
  {
    aliases: ['هاي بيوتك', 'هايبوتك', 'هايبيوتك', 'hibiotic', 'ibiotic'],
    tradeNameAr: 'هاي بيوتك 1 جم أقراص',
    ingredientId: 'amoxicillin-clavulanic-acid',
  },
  {
    aliases: ['كلافيموكس', 'كلافوكس', 'klavox', 'clavamox'],
    tradeNameAr: 'كلافوكس 1 جم أقراص',
    ingredientId: 'amoxicillin-clavulanic-acid',
  },
  {
    aliases: ['كورام', 'كيورام', 'كوران', 'curam'],
    tradeNameAr: 'كورام 1 جم أقراص',
    ingredientId: 'amoxicillin-clavulanic-acid',
  },
  {
    aliases: ['ميجاموكس', 'ميغاموكس', 'megamox'],
    tradeNameAr: 'ميجاموكس 1 جم أقراص',
    ingredientId: 'amoxicillin-clavulanic-acid',
  },
  {
    aliases: ['ايموكسكلاف', 'اموكسكلاف', 'emoxclav', 'e moxclav'],
    tradeNameAr: 'إيموكسكلاف 1 جم أقراص',
    ingredientId: 'amoxicillin-clavulanic-acid',
  },
  {
    aliases: ['اموكسيل', 'أموكسيل', 'amoxil'],
    tradeNameAr: 'أموكسيل 500 مجم كبسول',
    ingredientId: 'amoxicillin',
  },
  {
    aliases: ['ايموكس', 'إيموكس', 'emox', 'e mox', 'biomox', 'بيوموكس'],
    tradeNameAr: 'إيموكس 500 مجم كبسول',
    ingredientId: 'amoxicillin',
  },
  {
    aliases: ['فلاجيل', 'فلاحيل', 'فلاجل', 'flagyl', 'lagyl'],
    tradeNameAr: 'فلاجيل 500 مجم أقراص',
    ingredientId: 'metronidazole',
  },
  {
    aliases: ['امريزول', 'أمريزول', 'amrizole'],
    tradeNameAr: 'أمريزول 500 مجم أقراص',
    ingredientId: 'metronidazole',
  },
  {
    aliases: ['سيبروفار', 'سبروفار', 'ciprofar'],
    tradeNameAr: 'سيبروفار 500 مجم أقراص',
    ingredientId: 'ciprofloxacin',
  },
  {
    aliases: ['سيبروباي', 'ciprobay'],
    tradeNameAr: 'سيبروباي 500 مجم أقراص',
    ingredientId: 'ciprofloxacin',
  },
  {
    aliases: ['سيبروسين', 'ciprocin'],
    tradeNameAr: 'سيبروسين 500 مجم أقراص',
    ingredientId: 'ciprofloxacin',
  },
  {
    aliases: ['سيبروماي', 'cipromay'],
    tradeNameAr: 'سيبروماي 500 مجم أقراص',
    ingredientId: 'ciprofloxacin',
  },
  {
    aliases: ['تافانيك', 'تافانك', 'tavanic'],
    tradeNameAr: 'تافانيك 500 مجم أقراص',
    ingredientId: 'levofloxacin',
  },
  {
    aliases: ['ليفوكسين', 'levoxin'],
    tradeNameAr: 'ليفوكسين 500 مجم أقراص',
    ingredientId: 'levofloxacin',
  },
  {
    aliases: ['ليفوديل', 'levodel'],
    tradeNameAr: 'ليفوديل 500 مجم أقراص',
    ingredientId: 'levofloxacin',
  },
  {
    aliases: ['أفيلوكس', 'افيلوكس', 'افالوكس', 'avelox', 'avalox', 'موكسيفلوكس', 'moxiflox', 'فيجاموكس', 'vigamox'],
    tradeNameAr: 'أفيلوكس 400 مجم أقراص',
    ingredientId: 'moxifloxacin',
  },
  {
    aliases: ['سيبوريكس', 'كيبوركس', 'كيبركس', 'ceporex', 'كفلكس', 'keflex', 'ايبيلكس', 'إيبيلكس', 'ibilex', 'أوسبكسين', 'ospexin'],
    tradeNameAr: 'سيبوريكس 1 جم أقراص',
    ingredientId: 'cephalexin',
  },
  {
    aliases: ['يوناسين', 'يوناسن', 'unasyn', 'سيغماسين', 'sigmacyn', 'ألتراسيللين', 'ultracillin', 'سولبين', 'sulbin'],
    tradeNameAr: 'يوناسين 375 مجم أقراص',
    ingredientId: 'ampicillin-sulbactam',
  },
  {
    aliases: ['فلوكسامو', 'فلوكساموكس', 'floxamo', 'فلوسيل', 'flucil', 'فلوكسابكت', 'floxabact'],
    tradeNameAr: 'فلوكسامو 500 مجم كبسول',
    ingredientId: 'flucloxacillin',
  },
  {
    aliases: ['روسيفين', 'rocephin', 'سيفترياكسون', 'ceftriaxone', 'وينترياكسون', 'wintriaxone', 'سيفاكسون', 'cefaxone', 'إبيسفين', 'epicephin'],
    tradeNameAr: 'روسيفين 1 جم فيال',
    ingredientId: 'ceftriaxone',
  },
  {
    aliases: ['سيفوتاكس', 'cefotax', 'كلافوران', 'claforan', 'راميسيفت', 'ramiceft'],
    tradeNameAr: 'سيفوتاكس 1 جم فيال',
    ingredientId: 'cefotaxime',
  },
  {
    aliases: ['سوبراكس', 'suprax', 'سيفيكس', 'cefix', 'زيماسيف', 'ximacef', 'ماجناسيف', 'magnacef'],
    tradeNameAr: 'سوبراكس 400 مجم كبسول',
    ingredientId: 'cefixime',
  },
  {
    aliases: ['زينات', 'زيناكس', 'zinnat', 'زيناسيف', 'zinacef', 'سيفوروكس', 'cefurox'],
    tradeNameAr: 'زينات 500 مجم أقراص',
    ingredientId: 'cefuroxime',
  },
  {
    aliases: ['ديوريسيف', 'duricef', 'بيودروكسيل', 'biodroxil', 'إيبيدروكسيل', 'ibidroxil', 'كيريسيف', 'curisafe'],
    tradeNameAr: 'ديوريسيف 500 مجم كبسول',
    ingredientId: 'cefadroxil',
  },
  {
    aliases: ['أومنيسيف', 'omnicef', 'سيفدين', 'cefdin', 'دينار', 'dinar'],
    tradeNameAr: 'أومنيسيف 300 مجم كبسول',
    ingredientId: 'cefdinir',
  },
  {
    aliases: ['سيلبيرازون', 'sulperazon', 'سيفوزون', 'cefozone', 'بيراكتام', 'peractam'],
    tradeNameAr: 'سيلبيرازون 1 جم فيال',
    ingredientId: 'cefoperazone-sulbactam',
  },
  {
    aliases: ['ماكسيبيم', 'maxipime', 'سيفيبيم', 'cefepime', 'وينسيف', 'wincef'],
    tradeNameAr: 'ماكسيبيم 1 جم فيال',
    ingredientId: 'cefepime',
  },
  {
    aliases: ['كلاسيد', 'klacid', 'كلاريكان', 'clarikan', 'كلاريثرو', 'clarithro'],
    tradeNameAr: 'كلاسيد 500 مجم أقراص',
    ingredientId: 'clarithromycin',
  },
  {
    aliases: ['إريثروسين', 'اريثروسين', 'erythrocin', 'إريثرومايسين', 'erythromycin', 'أكني مايسين', 'aknemycin'],
    tradeNameAr: 'إريثروسين 500 مجم أقراص',
    ingredientId: 'erythromycin',
  },
  {
    aliases: ['فيبراميسين', 'vibramycin', 'تابوسين', 'tabocin', 'دوكسي', 'doxymycin', 'doxycost'],
    tradeNameAr: 'فيبراميسين 100 مجم كبسول',
    ingredientId: 'doxycycline',
  },
  {
    aliases: ['دالاسين', 'dalacin', 'كليندام', 'clindam', 'ألفاكليند', 'alfaclind', 'كلينداسول', 'clindasol'],
    tradeNameAr: 'دالاسين سي 300 مجم كبسول',
    ingredientId: 'clindamycin',
  },
  {
    aliases: ['ماكروفيوران', 'macrofuran', 'يوفامين', 'uvamin', 'ميبافيوران', 'mepafuran'],
    tradeNameAr: 'ماكروفيوران 100 مجم كبسول',
    ingredientId: 'nitrofurantoin',
  },
  {
    aliases: ['سبترين', 'septrin', 'سوتريم', 'sutrim', 'سبتازول', 'septazole'],
    tradeNameAr: 'سبترين مضاعف القوة أقراص',
    ingredientId: 'co-trimoxazole',
  },
  {
    aliases: ['جاراميسين', 'garamycin', 'إيبيجنت', 'epigent', 'جنتاميسين', 'gentamycin'],
    tradeNameAr: 'جاراميسين 80 مجم أمبول',
    ingredientId: 'gentamicin',
  },
  {
    aliases: ['أميكين', 'اميكين', 'amikin', 'أميكابيوتك', 'amikabiotic', 'ميكاسين', 'mikacin'],
    tradeNameAr: 'أميكين 500 مجم فيال',
    ingredientId: 'amikacin',
  },
  {
    aliases: ['ميرونيم', 'meronem', 'ميروبينيم', 'meropenem'],
    tradeNameAr: 'ميرونيم 1 جم فيال',
    ingredientId: 'meropenem',
  },
  {
    aliases: ['فانكوسين', 'vancocin', 'فانكوميكس', 'vancomix', 'سيلوفان', 'celovan'],
    tradeNameAr: 'فانكوميكس 500 مجم فيال',
    ingredientId: 'vancomycin',
  },
  {
    aliases: ['زيفوكس', 'zyvox', 'أفيروزوليد', 'averozolid', 'لينوليد', 'linolid'],
    tradeNameAr: 'زيفوكس 600 مجم أقراص',
    ingredientId: 'linezolid',
  },
  {
    aliases: ['فيوسيدين', 'fucidin', 'فيوسيديرم', 'fusiderm', 'فيوسيباكت', 'fusibact', 'فيوسيثالمك', 'fucithalmic', 'fucitop'],
    tradeNameAr: 'فيوسيدين 2% كريم',
    ingredientId: 'fusidic-acid',
  },
  {
    aliases: ['تراسيد', 'trcid', 'جاستروبيوتك', 'gastrobiotic', 'إندوريفاكس', 'endorifax', 'rifaximin'],
    tradeNameAr: 'تراسيد 200 مجم أقراص',
    ingredientId: 'rifaximin',
  },
  {
    aliases: ['أوسبين', 'اوسبين', 'ospen', 'بنسلين', 'فينوكسي'],
    tradeNameAr: 'أوسبين 1000 مجم أقراص',
    ingredientId: 'penicillin-v-potassium',
  },
];

const DRUG_KEYWORD_TO_ID: Array<{ pattern: RegExp; id: string; label: string }> = [
  { pattern: /(augmentin|hibiotic|\bcuram\b|megamox|klavox|emoxclav|amoxicillin\s*\+?\s*clav|اوجمنتين|أوجمنتين|اوغمنتين|هاي\s*بيوتك|كيورام|كورام|ميجاموكس|كلافوكس|ايموكسكلاف)/i, id: 'amoxicillin-clavulanic-acid', label: 'Augmentin / Amoxicillin-Clavulanate (أوجمنتين)' },
  { pattern: /(amoxicillin|amoxil|\be-mox\b|\bemox\b|biomox|اموكسيسيلين|أموكسيسيلين|اموكسيل|ايموكس)/i, id: 'amoxicillin', label: 'Amoxicillin (أموكسيسيلين)' },
  { pattern: /(unasyn|sigmacyn|ultracillin|ampicillin\s*\+?\s*sulbactam|يوناسين|امبيسيلين)/i, id: 'ampicillin-sulbactam', label: 'Unasyn / Ampicillin-Sulbactam (يوناسين)' },
  { pattern: /(floxamo|flucil|flucloxacillin|فلوكسامو|فلوسيل|فلوكلوكساسيللين)/i, id: 'flucloxacillin', label: 'Flucloxacillin (فلوكسامو)' },
  { pattern: /(\bospen\b|penicillin\s*v|اوسبن|أوسبن|اوسبين|أوسبين|بنسلين)/i, id: 'penicillin-v-potassium', label: 'Penicillin V / Ospen (أوسبن)' },
  { pattern: /(ceporex|ospexin|keflex|ibilex|cephalexin|سيبوريكس|كيبوركس|اوسبكسين|سيفالكسين)/i, id: 'cephalexin', label: 'Cephalexin / Ceporex (كيبوركس)' },
  { pattern: /(duricef|biodroxil|ibidroxil|cefadroxil|ديوريسيف|بيودروكسيل|سيفادروكسيل)/i, id: 'cefadroxil', label: 'Cefadroxil / Duricef (ديوريسيف)' },
  { pattern: /(zinnat|zinacef|cefuroxime|زينات|سيفوروكسيم)/i, id: 'cefuroxime', label: 'Cefuroxime / Zinnat (زينات)' },
  { pattern: /(suprax|magnacef|ximacef|cefixime|سوبراكس|ماجناسيف|سيفيكسيم)/i, id: 'cefixime', label: 'Cefixime / Suprax (سوبراكس)' },
  { pattern: /(omnicef|\bdinar\b|cefdinir|اومنيسيف|أومنيسيف|دينار|سيفدينير)/i, id: 'cefdinir', label: 'Cefdinir / Omnicef (أومنيسيف)' },
  { pattern: /(rocephin|epicephin|cefaxone|wintriaxone|ceftriaxone|روسيفين|ابيسفين|إبيسفين|سيفاكسون|وينترياكسون|سيفترياكسون)/i, id: 'ceftriaxone', label: 'Ceftriaxone / Rocephin (روسيفين)' },
  { pattern: /(cefotax|claforan|cefotaxime|سيفوتاكس|كلافوران|سيفوتاكسيم)/i, id: 'cefotaxime', label: 'Cefotaxime / Cefotax (سيفوتاكس)' },
  { pattern: /(sulperazon|cefozone|cefoperazone|سيلبيرازون|سيفوبيرازون)/i, id: 'cefoperazone-sulbactam', label: 'Cefoperazone-Sulbactam / Sulperazon (سيلبيرازون)' },
  { pattern: /(maxipime|wincef|cefepime|ماكسيبيم|سيفيبيم)/i, id: 'cefepime', label: 'Cefepime / Maxipime (ماكسيبيم)' },
  { pattern: /(zithromax|ithromax|xithrone|zithrokan|epizithro|zisrocin|azithromycin|delzosin|زيثروماكس|ريثروماكس|زيتروماكس|يثروماكس|زيثرون|زيثروكان|ايبيزيثرو|زيسروسين|ازيثرومايسين|أزيثرومايسين)/i, id: 'azithromycin', label: 'Azithromycin / Zithromax (زيثروماكس)' },
  { pattern: /(klacid|clarikan|clarithromycin|كلاسيد|كلاريكان|كلاريثرومايسين)/i, id: 'clarithromycin', label: 'Clarithromycin / Klacid (كلاسيد)' },
  { pattern: /(erythrocin|erythromycin|اريثروسين|إريثرومايسين)/i, id: 'erythromycin', label: 'Erythromycin (إريثرومايسين)' },
  { pattern: /(ciprofar|ciprobay|ciprofloxacin|ciprocin|cipromay|سيبروفار|سبروفار|سيبروباي|سيبروسين|سيبروفلوكساسين)/i, id: 'ciprofloxacin', label: 'Ciprofloxacin / Ciprofar (سيبروفار)' },
  { pattern: /(tavanic|levoxin|levodel|tarivid|levofloxacin|تافانيك|تافانك|ليفوكسين|ليفوديل|ليفوفلوكساسين)/i, id: 'levofloxacin', label: 'Levofloxacin / Tavanic (تافانيك)' },
  { pattern: /(avelox|avalox|moxiflox|vigamox|moxifloxacin|افيلوكس|أفيلوكس|موكسيفلوكساسين)/i, id: 'moxifloxacin', label: 'Moxifloxacin / Avelox (أفيلوكس)' },
  { pattern: /(vibramycin|tabocin|doxymycin|doxycycline|فيبراميسين|تابوسين|دوكسيسيكلين)/i, id: 'doxycycline', label: 'Doxycycline / Vibramycin (تابوسين)' },
  { pattern: /(dalacin|clindamycin|clindam|alfaclind|دالاسين|كليندام|كليندامايسين)/i, id: 'clindamycin', label: 'Clindamycin / Dalacin C (دالاسين)' },
  { pattern: /(flagyl|amrizole|metronidazole|فلاجيل|فلاحيل|امريزول|أمريزول|ميترونيدازول)/i, id: 'metronidazole', label: 'Metronidazole / Flagyl (فلاجيل)' },
  { pattern: /(macrofuran|uvamin|mepafuran|nitrofurantoin|ماكروفيوران|يوفامين|نيتروفورانتوين)/i, id: 'nitrofurantoin', label: 'Nitrofurantoin / Macrofuran (ماكروفيوران)' },
  { pattern: /(septazole|sutrim|septrin|co-trimoxazole|trimethoprim|سبتازول|سبترين|سوتريم|كوتريموكسازول)/i, id: 'co-trimoxazole', label: 'Co-trimoxazole / Septazole (سبتازول)' },
  { pattern: /(garamycin|epigent|gentamicin|جاراميسين|جنتامايسين)/i, id: 'gentamicin', label: 'Gentamicin / Garamycin (جاراميسين)' },
  { pattern: /(amikin|amikabiotic|mikacin|amikacin|اميكين|أميكين|أميكاسين)/i, id: 'amikacin', label: 'Amikacin / Amikin (أميكين)' },
  { pattern: /(meronem|meropenem|ميرونيم|ميروبينيم)/i, id: 'meropenem', label: 'Meropenem / Meronem (ميرونيم)' },
  { pattern: /(vancocin|vancomix|vancomycin|فانكوسين|فانكومايسين)/i, id: 'vancomycin', label: 'Vancomycin (فانكومايسين)' },
  { pattern: /(\bzyvox\b|averozolid|linolid|linezolid|زيفوكس|افيروزوليد|أفيروزوليد|لينيزوليد)/i, id: 'linezolid', label: 'Linezolid / Averozolid (أفيروزوليد)' },
  { pattern: /(fucidin|fusiderm|fusibact|fusidic|فيوسيدين|فيوسيديرم|حمض الفيوسيديك)/i, id: 'fusidic-acid', label: 'Fusidic Acid / Fucidin (فيوسيدين)' },
  { pattern: /(\btrcid\b|gastrobiotic|endorifax|rifaximin|تراسيد|جاستروبيوتك|ريفاكسيمين)/i, id: 'rifaximin', label: 'Rifaximin / Gastrobiotic (تراسيد)' },
];

/**
 * Universal Bilingual Scoring Matcher across all 206 Egyptian Commercial Products,
 * 32 Active Ingredients, and OCR Phonetic/Dot-Skeleton Aliases.
 */
export function matchEgyptianDrugFromText(rawText: string): {
  matchedProduct: EgyptianCommercialProduct | null;
  matchedIngredientId: string | null;
  detectedDrugName: string;
  score: number;
} {
  const raw = (rawText || '').trim();
  if (!raw || raw.length < 2) {
    return { matchedProduct: null, matchedIngredientId: null, detectedDrugName: '', score: 0 };
  }

  // 0) First check the full 26,597 Egyptian Medicine Database (Brand-First + Strength + Form)
  const hit26k = findDawayaIndexItemSync(raw);
  if (hit26k) {
    const asComm = dawayaIndexItemToCommercialProduct(hit26k);
    return {
      matchedProduct: asComm,
      matchedIngredientId: hit26k.i,
      detectedDrugName: hit26k.a ? `${hit26k.a} (${hit26k.n})` : hit26k.n,
      score: 165,
    };
  }

  const clean = normalizePharmaText(raw);
  const cleanWords = clean.split(' ');
  const inWords = cleanWords.filter(
    (w) =>
      w.length >= 2 &&
      !PHARMA_STOP_WORDS.has(w) &&
      !/^\d+(mg|g|gm|ml|mcg|iu)?$/.test(w)
  );

  let bestProd: EgyptianCommercialProduct | null = null;
  let bestScore = 0;

  for (const p of EGYPTIAN_COMMERCIAL_PRODUCTS) {
    const arWords = normalizePharmaText(p.tradeNameAr)
      .split(' ')
      .filter((w) => w.length >= 2 && !PHARMA_STOP_WORDS.has(w) && !/^\d+$/.test(w));
    const enWords = normalizePharmaText(p.tradeNameEn)
      .split(' ')
      .filter(
        (w) =>
          w.length >= 2 &&
          !PHARMA_STOP_WORDS.has(w) &&
          !/^\d+(mg|g|gm|ml|mcg|iu)?$/.test(w)
      );

    const arBrand =
      arWords.length >= 2 && arWords[0].length <= 3
        ? `${arWords[0]} ${arWords[1]}`
        : arWords[0] || '';
    const enBrand =
      enWords.length >= 2 && enWords[0].length <= 2
        ? `${enWords[0]} ${enWords[1]}`
        : enWords[0] || '';

    let score = 0;

    // A. Exact Brand Match in English or Arabic
    if (
      enBrand &&
      enBrand.length >= 3 &&
      (cleanWords.includes(enBrand) || (enBrand.length >= 4 && clean.includes(enBrand)))
    ) {
      score = Math.max(score, 130 + enBrand.length * 3);
    }
    if (
      arBrand &&
      arBrand.length >= 3 &&
      (cleanWords.includes(arBrand) || (arBrand.length >= 4 && clean.includes(arBrand)))
    ) {
      score = Math.max(score, 130 + arBrand.length * 3);
    }

    // B. OCR_ALIASES check
    if (score === 0) {
      for (const entry of OCR_ALIASES) {
        if (entry.ingredientId === p.activeIngredientId) {
          const aliasHit = entry.aliases.some((al) => {
            const alNorm = normalizePharmaText(al);
            return alNorm.length >= 4 && clean.includes(alNorm);
          });
          if (aliasHit && p.tradeNameAr.includes(entry.tradeNameAr.split(' ')[0])) {
            score = Math.max(score, 128);
          }
        }
      }
    }

    // C. Fuzzy Levenshtein & Arabic Dot-Skeleton Match on Brand Words ONLY (never substitute random brand from active ingredient)
    if (score === 0) {
      for (const iw of inWords) {
        if (iw.length >= 4 && !isPureGenericIngredientQuery(iw)) {
          if (enBrand && enBrand.length >= 4) {
            const simEn = stringSimilarity(iw, enBrand);
            if (simEn >= 0.88) {
              score = Math.max(score, Math.round(simEn * 105));
            }
          }
          if (arBrand && arBrand.length >= 3) {
            const simAr = stringSimilarity(iw, arBrand);
            const simSkel = stringSimilarity(
              normalizeArabicSkeleton(iw),
              normalizeArabicSkeleton(arBrand)
            );
            if (simAr >= 0.88 || simSkel >= 0.90) {
              score = Math.max(score, Math.round(Math.max(simAr, simSkel) * 105));
            }
          }
        }
      }
    }

    // E. Secondary Tie-Breaker: Strength & Dosage Form
    if (score > 0) {
      const strengthNums = p.strength.match(/\d+/g) || [];
      for (const num of strengthNums) {
        if (cleanWords.includes(num) || clean.includes(`${num}mg`) || clean.includes(`${num}g`)) {
          score += 15;
        }
      }
      const formKeywords = [
        'شراب', 'suspension', 'كبسول', 'capsule', 'اقراص', 'tablet',
        'فيال', 'vial', 'امبول', 'ampoule', 'كريم', 'cream', 'نقط', 'drops',
      ];
      const prodNorm = `${normalizePharmaText(p.tradeNameAr)} ${normalizePharmaText(p.tradeNameEn)}`;
      for (const fk of formKeywords) {
        if (clean.includes(fk) && prodNorm.includes(fk)) {
          score += 10;
        }
      }
    }

    if (score > bestScore) {
      bestScore = score;
      bestProd = p;
    }
  }

  if (bestProd && bestScore >= 120) {
    return {
      matchedProduct: bestProd,
      matchedIngredientId: bestProd.activeIngredientId,
      detectedDrugName: `${bestProd.tradeNameAr} (${bestProd.tradeNameEn})`,
      score: bestScore,
    };
  }

  return { matchedProduct: null, matchedIngredientId: null, detectedDrugName: '', score: 0 };
}

/**
 * Downscales large camera/gallery images in the browser
 */
export async function prepareImageForOcrAndVision(
  base64OrDataUrl: string,
  mimeType = 'image/jpeg'
): Promise<{
  dataUri: string;
  base64Data: string;
  mimeType: string;
  nativeBarcode: string | null;
}> {
  const rawDataUri = base64OrDataUrl.startsWith('data:')
    ? base64OrDataUrl
    : `data:${mimeType || 'image/jpeg'};base64,${base64OrDataUrl}`;
  const rawBase64 = rawDataUri.includes(',') ? rawDataUri.split(',')[1] : base64OrDataUrl;

  if (typeof document === 'undefined' || typeof Image === 'undefined') {
    return {
      dataUri: rawDataUri,
      base64Data: rawBase64,
      mimeType: mimeType || 'image/jpeg',
      nativeBarcode: null,
    };
  }

  try {
    const img = new Image();
    img.src = rawDataUri;
    await new Promise((res, rej) => {
      img.onload = res;
      img.onerror = rej;
    });

    const maxDim = 1400;
    let w = img.width || 600;
    let h = img.height || 600;
    if (w > maxDim || h > maxDim) {
      if (w > h) {
        h = Math.round((h * maxDim) / w);
        w = maxDim;
      } else {
        w = Math.round((w * maxDim) / h);
        h = maxDim;
      }
    }

    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      return {
        dataUri: rawDataUri,
        base64Data: rawBase64,
        mimeType: mimeType || 'image/jpeg',
        nativeBarcode: null,
      };
    }

    ctx.drawImage(img, 0, 0, w, h);
    const normalizedDataUri = canvas.toDataURL('image/jpeg', 0.88);
    const normalizedBase64 = normalizedDataUri.split(',')[1] || rawBase64;

    let nativeBarcode: string | null = null;
    if (typeof window !== 'undefined' && 'BarcodeDetector' in window) {
      try {
        const detector = new (window as unknown as {
          BarcodeDetector: new (opts: { formats: string[] }) => {
            detect: (el: HTMLCanvasElement) => Promise<Array<{ rawValue?: string }>>;
          };
        }).BarcodeDetector({
          formats: ['ean_13', 'code_128', 'qr_code', 'data_matrix', 'upc_a'],
        });
        const barcodes = await detector.detect(canvas);
        if (barcodes && barcodes.length > 0 && barcodes[0].rawValue) {
          nativeBarcode = barcodes[0].rawValue;
        }
      } catch {
        /* ignore */
      }
    }

    return {
      dataUri: normalizedDataUri,
      base64Data: normalizedBase64,
      mimeType: 'image/jpeg',
      nativeBarcode,
    };
  } catch {
    return {
      dataUri: rawDataUri,
      base64Data: rawBase64,
      mimeType: mimeType || 'image/jpeg',
      nativeBarcode: null,
    };
  }
}

/**
 * Local in-browser OCR fallback via Tesseract.js (eng+ara)
 */
export async function performBrowserTesseractOcr(imageDataUrl: string): Promise<string> {
  if (typeof window === 'undefined' || typeof document === 'undefined') return '';
  try {
    const win = window as unknown as {
      Tesseract?: {
        recognize: (
          img: string,
          langs: string,
          opts?: { logger?: () => void }
        ) => Promise<{ data?: { text?: string } }>;
      };
    };
    if (!win.Tesseract) {
      await new Promise<void>((resolve, reject) => {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
        script.async = true;
        script.onload = () => resolve();
        script.onerror = () => reject(new Error('OCR_LOAD_FAILED'));
        document.head.appendChild(script);
      });
    }
    if (win.Tesseract) {
      const res = await win.Tesseract.recognize(imageDataUrl, 'eng+ara', {
        logger: () => {},
      });
      return res?.data?.text || '';
    }
  } catch {
    /* ignore */
  }
  return '';
}

/**
 * Zero-Hint Vision Text Transcriber:
 * Uses a prompt with ZERO medicine names or examples so the model can never echo
 * or hallucinate a drug name from the prompt. Filters out refusals or conversational replies.
 */
async function runZeroHintVisionOcr(_dataUri: string): Promise<string> {
  // Section 6 Security Fix: Never transmit patient medical/prescription images to third-party public endpoints.
  return '';
}

async function runCloudOcrNonColliding(_dataUri: string): Promise<string> {
  // Section 6 Security Fix: Never transmit patient medical/prescription images to public shared-key OCR services.
  return '';
}

function parseVisionText(rawText: string): {
  detectedDrugName: string;
  genericName: string;
  matchedIngredientId: string | null;
  summary: string;
} {
  const lines = rawText.split(/\r?\n/);
  let matchedId: string | null = null;
  let detectedName = '';
  let genericName = '';
  const summaryLines: string[] = [];

  for (const rawLine of lines) {
    const line = rawLine
      .trim()
      .replace(/^[*•\-–\d.]+\s*/, '')
      .replace(/\*\*/g, '')
      .trim();
    if (!line) continue;

    const idMatch = line.match(/^(?:RX_)?DRUG_ID:\s*([a-z0-9-]+)/i);
    const nameMatch = line.match(/^(?:RX_)?(?:DRUG_NAME|MEDICINE_NAME|TRADE_NAME|الاسم التجاري|اسم الدواء):\s*(.+)/i);
    const genMatch = line.match(/^(?:GENERIC_NAME|ACTIVE_INGREDIENT|المادة الفعالة):\s*(.+)/i);
    const sumMatch = line.match(/^(?:SUMMARY|RX_NOTES|الملخص):\s*(.+)/i);
    if (idMatch) {
      const val = idMatch[1].toLowerCase().trim();
      if (val !== 'unknown' && val !== 'unreadable' && KNOWN_INGREDIENT_SLUGS.has(val)) matchedId = val;
    } else if (nameMatch) {
      const val = nameMatch[1].replace(/^\[|\]$/g, '').trim();
      if (!/^(unreadable|unknown|none|null|n\/a|غير واضح|غير مقروء)$/i.test(val)) {
        detectedName = val;
      }
    } else if (genMatch) {
      const val = genMatch[1].replace(/^\[|\]$/g, '').trim();
      if (!/^(unreadable|unknown|none|null|n\/a|غير واضح|غير مقروء)$/i.test(val)) {
        genericName = val;
      }
    } else if (sumMatch) {
      summaryLines.push(sumMatch[1].trim());
    } else if (!/^(RX_|DRUG_|GENERIC_)/i.test(line)) {
      summaryLines.push(rawLine);
    }
  }

  // If detectedName has "Brand (Generic)" where inside parentheses is a generic ingredient, keep the Brand part clean
  if (detectedName) {
    const pm = detectedName.match(/^(.+?)\s*\(([^)]+)\)\s*$/);
    if (pm && isPureGenericIngredientQuery(pm[2]) && !isPureGenericIngredientQuery(pm[1])) {
      if (!genericName) genericName = pm[2].trim();
      detectedName = pm[1].trim();
    }
  }

  return {
    detectedDrugName: detectedName || genericName,
    genericName,
    matchedIngredientId: matchedId,
    summary: cleanAssistantMarkdown(summaryLines.join('\n')),
  };
}

export async function analyzeMedicineImageWithVision(
  base64Data: string,
  mimeType: string,
  lang: Lang
): Promise<VisionAnalysisResult> {
  await ensureDawayaDatabaseLoaded().catch(() => {});
  const prepared = await prepareImageForOcrAndVision(base64Data, mimeType);
  const dataUri = prepared.dataUri;

  const prompt =
    lang === 'ar'
      ? `أنت صيدلي مصري خبير. اقرأ الاسم التجاري للدواء (Trade/Brand Name المطبوع بخط كبير ورئيسي على علبة الدواء أو شريط البرشام) مع التركيز والشكل الصيدلاني بدقة تامة كما هو مكتوب في الصورة.
تحذير هام جداً: إياك أن تكتب اسم المادة الفعالة (Generic/Active Ingredient المكتوبة بخط أصغر تحت الاسم التجاري) في خانة DRUG_NAME، بل اكتب الاسم التجاري للدواء في DRUG_NAME وضع المادة الفعالة في GENERIC_NAME فقط.
اكتب النتيجة في 3 أسطر فقط بالصيغة التالية مباشرة بدون أي علامات ترقيم إضافية:
DRUG_NAME: <الاسم التجاري للدواء المكتوب على العلبة أو الشريط مع التركيز والشكل الصيدلاني، أو UNREADABLE لو غير واضح>
GENERIC_NAME: <المادة الفعالة المكتوبة على العلبة إن وجدت، أو NONE>
SUMMARY: <ملخص طبي مختصر في سطرين عن هذا الدواء ودواعي استعماله>`
      : `You are an expert Egyptian pharmacist. Read the exact printed COMMERCIAL TRADE/BRAND NAME on the medicine box, bottle, tube, or blister strip in this image along with its strength and dosage form.
CRITICAL RULE: Never put the generic active ingredient (printed in smaller font under the brand name) in DRUG_NAME. Always put the commercial brand name in DRUG_NAME and the active ingredient in GENERIC_NAME.
Output strictly in these 3 lines:
DRUG_NAME: <exact printed commercial brand name, strength, and dosage form, or UNREADABLE>
GENERIC_NAME: <printed active ingredient if visible, or NONE>
SUMMARY: <brief 2-line clinical summary of this medication>`;

  const geminiText = hasApiKey()
    ? await callServerAiProxy({
        prompt,
        inlineImageBase64: prepared.base64Data,
        mimeType: prepared.mimeType || 'image/jpeg',
        model: 'gemini-2.5-flash',
      }).catch(() => '')
    : '';

  const parsedGemini = geminiText
    ? parseVisionText(geminiText)
    : { detectedDrugName: '', genericName: '', matchedIngredientId: null, summary: '' };

  // 1) If native barcode was found on the box/strip, check full 26,597 database first
  if (prepared.nativeBarcode) {
    const bcHit = findDawayaIndexItemSync(prepared.nativeBarcode);
    if (bcHit) {
      return {
        detectedDrugName: `${bcHit.a} (${bcHit.n})`,
        matchedIngredientId: bcHit.i,
        summary: parsedGemini.summary,
        rawExtractedText: `${bcHit.n} ${bcHit.a} ${bcHit.g}`,
      };
    }
  }

  // 2) If AI Vision returned a commercial brand name, resolve it (with genericName synergy) against the 26,597 database!
  if (parsedGemini.detectedDrugName && !isPureGenericIngredientQuery(parsedGemini.detectedDrugName)) {
    const combinedVisionLookup = [parsedGemini.detectedDrugName, parsedGemini.genericName]
      .filter(Boolean)
      .join('\n');
    const direct26k =
      findDawayaIndexItemSync(combinedVisionLookup) ||
      findDawayaIndexItemSync(parsedGemini.detectedDrugName);
    if (direct26k) {
      return {
        detectedDrugName: `${direct26k.a} (${direct26k.n})`,
        matchedIngredientId: direct26k.i,
        summary: parsedGemini.summary,
        rawExtractedText: `${ direct26k.n } ${ direct26k.a }`,
      };
    }
    return {
      detectedDrugName: parsedGemini.detectedDrugName,
      matchedIngredientId: parsedGemini.matchedIngredientId,
      summary: parsedGemini.summary,
      rawExtractedText: parsedGemini.detectedDrugName,
    };
  }

  // 3) Run local Tesseract OCR if Vision returned nothing OR if Vision only returned a generic active ingredient name
  const localTesseractText = await performBrowserTesseractOcr(dataUri);
  const combinedOcrAndVision = [
    localTesseractText || '',
    parsedGemini.detectedDrugName || '',
    parsedGemini.genericName || '',
     parsedGemini.summary || '',
  ]
    .filter(Boolean)
    .join('\n')
    .trim();

  if (combinedOcrAndVision.length >= 3) {
    const directOcr26k = findDawayaIndexItemSync(combinedOcrAndVision);
    if (directOcr26k) {
      return {
        detectedDrugName: `${directOcr26k.a} (${directOcr26k.n})`,
        matchedIngredientId: directOcr26k.i,
        summary: parsedGemini.summary,
        rawExtractedText: `${directOcr26k.n} ${directOcr26k.a}`,
      };
    }
  }

  return {
    detectedDrugName: parsedGemini.detectedDrugName || '',
    matchedIngredientId: parsedGemini.matchedIngredientId,
    summary: parsedGemini.summary,
    rawExtractedText: localTesseractText || '',
  };
}

export interface PrescriptionOcrExtractionResult {
  detectedDrugName: string;
  matchedIngredientId: string | null;
  extractedDoseText: string;
  extractedRoute: 'oral' | 'suspension' | 'injection' | 'topical' | '';
  extractedFrequencyKey: 'once_daily' | 'twice_daily' | 'thrice_daily' | 'four_times_daily' | '';
  extractedFrequencyRaw: string;
  extractedDurationDays: number | null;
  extractedNotes: string;
  extractedCoMeds: string[];
  unreadableFields: string[];
  contradictionWarnings: string[];
  rawExtractedText: string;
  isUnverifiedOcr: true;
  autoApproved: false;
}

function isUnreadableToken(val: string): boolean {
  const clean = (val || '').trim().toLowerCase();
  if (!clean) return true;
  return (
    clean === 'unreadable' ||
    clean === 'unknown' ||
    clean === 'missing' ||
    clean === 'none' ||
    clean === 'n/a' ||
    clean === 'null' ||
    clean === '?' ||
    clean === 'غير واضح' ||
    clean === 'غير مقروء' ||
    clean === 'غير مذكور' ||
    clean === 'غير محدد'
  );
}

/**
 * Deterministically parses structured vision output and/or raw OCR text from a prescription
 * without ever inventing a medication dose, frequency, duration, or administration route.
 */
export function parsePrescriptionTextDeterministically(
  rawText: string
): PrescriptionOcrExtractionResult {
  const text = (rawText || '').trim();
  let matchedIngredientId: string | null = null;
  let detectedDrugName = '';
  let extractedDoseText = '';
  let extractedRoute: 'oral' | 'suspension' | 'injection' | 'topical' | '' = '';
  let extractedFrequencyKey: 'once_daily' | 'twice_daily' | 'thrice_daily' | 'four_times_daily' | '' = '';
  let extractedFrequencyRaw = '';
  let extractedDurationDays: number | null = null;
  let extractedNotes = '';
  const extractedCoMeds: string[] = [];
  const contradictionWarnings: string[] = [];

  const lines = text.split(/\r?\n/);
  for (const rawLine of lines) {
    const line = rawLine
      .trim()
      .replace(/^[*•\-–]+\s*/, '')
      .replace(/\*\*/g, '')
      .trim();
    if (!line) continue;

    const idMatch = line.match(/^(?:RX_DRUG_ID|DRUG_ID):\s*(.+)$/i);
    if (idMatch) {
      const candidate = idMatch[1].trim().toLowerCase();
      if (!isUnreadableToken(candidate) && KNOWN_INGREDIENT_SLUGS.has(candidate)) {
        matchedIngredientId = candidate;
      }
      continue;
    }

    const nameMatch = line.match(/^(?:RX_DRUG_NAME|DRUG_NAME):\s*(.+)$/i);
    if (nameMatch) {
      const val = nameMatch[1].replace(/^\[|\]$/g, '').trim();
      const hasOcrNoiseSymbols = /[<>|]/.test(val);
      if (!isUnreadableToken(val) && !hasOcrNoiseSymbols) detectedDrugName = val;
      continue;
    }

    const doseMatch = line.match(/^RX_DOSE:\s*(.+)$/i);
    if (doseMatch) {
      const val = doseMatch[1].replace(/^\[|\]$/g, '').trim();
      if (!isUnreadableToken(val)) extractedDoseText = val;
      continue;
    }

    const routeMatch = line.match(/^RX_ROUTE:\s*(.+)$/i);
    if (routeMatch) {
      const val = routeMatch[1].trim().toLowerCase();
      if (val === 'oral' || val === 'suspension' || val === 'injection' || val === 'topical') {
        extractedRoute = val;
      }
      continue;
    }

    const freqMatch = line.match(/^RX_FREQ:\s*(.+)$/i);
    if (freqMatch) {
      const val = freqMatch[1].trim();
      if (!isUnreadableToken(val)) {
        extractedFrequencyRaw = val;
        const lower = val.toLowerCase();
        if (lower === 'once_daily' || lower === 'q24h') extractedFrequencyKey = 'once_daily';
        else if (lower === 'twice_daily' || lower === 'q12h') extractedFrequencyKey = 'twice_daily';
        else if (lower === 'thrice_daily' || lower === 'q8h') extractedFrequencyKey = 'thrice_daily';
        else if (lower === 'four_times_daily' || lower === 'q6h') extractedFrequencyKey = 'four_times_daily';
      }
      continue;
    }

    const durMatch = line.match(/^RX_DURATION_DAYS:\s*(.+)$/i);
    if (durMatch) {
      const val = durMatch[1].trim();
      if (!isUnreadableToken(val)) {
        const num = parseInt(val.replace(/[^\d]/g, ''), 10);
        if (!isNaN(num) && num >= 1 && num <= 60) {
          extractedDurationDays = num;
        }
      }
      continue;
    }

    const notesMatch = line.match(/^RX_NOTES:\s*(.+)$/i);
    if (notesMatch) {
      const val = notesMatch[1].trim();
      if (!isUnreadableToken(val)) extractedNotes = val;
      continue;
    }

    const contradictMatch = line.match(/^RX_CONTRADICTIONS:\s*(.+)$/i);
    if (contradictMatch) {
      const val = contradictMatch[1].trim();
      if (!isUnreadableToken(val)) contradictionWarnings.push(val);
      continue;
    }
  }

  // 1) If AI Vision extracted detectedDrugName via RX_DRUG_NAME:, resolve each drug against the 26,597 database
  if (detectedDrugName) {
    const drugParts = detectedDrugName
      .split(/\s*\+\s*/)
      .map((s) => s.trim())
      .filter(Boolean);
    const enrichedParts: string[] = [];
    for (const part of drugParts) {
      // Combine part with dose/route/notes context so strength & form (e.g. 600 mg, 500 mg, tablets) are always matched!
      const lookupWithContext =
        drugParts.length === 1
          ? [part, extractedDoseText, extractedRoute, isPureGenericIngredientQuery(part) ? extractedNotes : '']
              .filter(Boolean)
              .join(' ')
          : part;
      const hit = findDawayaIndexItemSync(lookupWithContext) || findDawayaIndexItemSync(part);
      if (hit) {
        if (!matchedIngredientId) matchedIngredientId = hit.i;
        const label = hit.a ? `${hit.a} (${hit.n})` : hit.n;
        if (!enrichedParts.includes(label)) enrichedParts.push(label);
      } else {
        const abxHit = matchEgyptianDrugFromText(lookupWithContext);
        if (abxHit.matchedIngredientId) {
          if (!matchedIngredientId) matchedIngredientId = abxHit.matchedIngredientId;
          if (!enrichedParts.includes(abxHit.detectedDrugName)) enrichedParts.push(abxHit.detectedDrugName);
        } else {
          enrichedParts.push(part);
        }
      }
    }
    if (enrichedParts.length > 0) {
      detectedDrugName = enrichedParts.join(' + ');
    }
  }

  // 2) Only if detectedDrugName was NOT found via RX_DRUG_NAME:, scan non-metadata lines against the 26,597 database
  if (!detectedDrugName) {
    const nonMetaLines: string[] = [];
    for (const rawLine of lines) {
      const trimmedLine = rawLine.trim();
      if (/^(?:RX_ROUTE|RX_DOSE|RX_FREQ|RX_DURATION_DAYS|RX_NOTES|RX_CONTRADICTIONS|RX_DRUG_ID|DRUG_ID|SUMMARY|GENERIC_NAME):/i.test(trimmedLine)) {
        continue;
      }
      const cleanL = trimmedLine
        .replace(/^(?:RX_DRUG_NAME|DRUG_NAME):\s*/i, '')
        .replace(/^[*•\-–\d.]+\s*/, '')
        .trim();
      if (cleanL.length >= 3 && !isUnreadableToken(cleanL) && !/^none$/i.test(cleanL)) {
        nonMetaLines.push(cleanL);
      }
    }

    // Check if the prescription has multiple bulleted/numbered R/ lines vs a single medicine box
    const rxBulletLines = lines.filter((l) => /^\s*(?:[-*•–]|\d+[.)]|R\/)\s*[A-Za-z\u0600-\u06FF]/i.test(l));
    if (rxBulletLines.length >= 2) {
      const found26k: string[] = [];
      const seenGenerics = new Set<string>();
      for (const bLine of rxBulletLines) {
        const cleanB = bLine.replace(/^\s*(?:R\/|[-*•–]|\d+[.)])+\s*/i, '').trim();
        const hit = findDawayaIndexItemSync(cleanB);
        if (hit) {
          if (isPureGenericIngredientQuery(cleanB) && seenGenerics.has((hit.g || '').toLowerCase())) {
            continue;
          }
          const label = hit.a ? `${hit.a} (${hit.n})` : hit.n;
          if (!found26k.includes(label)) found26k.push(label);
          if (hit.g) seenGenerics.add(hit.g.toLowerCase());
          if (!matchedIngredientId) matchedIngredientId = hit.i;
        }
      }
      if (found26k.length > 0) {
        detectedDrugName = found26k.join(' + ');
      }
    }

    // Single medicine box / blister strip / single-drug text: match across the combined non-metadata lines at once!
    if (!detectedDrugName && nonMetaLines.length > 0) {
      const combinedBoxText = nonMetaLines.join('\n');
      const boxHit = findDawayaIndexItemSync(combinedBoxText);
      if (boxHit) {
        detectedDrugName = boxHit.a ? `${boxHit.a} (${boxHit.n})` : boxHit.n;
        matchedIngredientId = boxHit.i;
      } else {
        const matched = matchEgyptianDrugFromText(combinedBoxText);
        if (matched.matchedIngredientId) {
          matchedIngredientId = matched.matchedIngredientId;
          detectedDrugName = matched.detectedDrugName;
        }
      }
    }
  }

  // Extract explicit dose strength/quantity ONLY if written in the text (never invented from DB!)
  if (!extractedDoseText) {
    const normalizedDigitsText = text.replace(/[٠-٩]/g, (d) =>
      String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    );
    const doseRegex =
      /(\d+(?:\.\d+)?\s*(?:mg|gm|g|ml|mcg|iu|مجم|ملجم|جم|جرام|مل|قرص|أقراص|اقراص|كبسولة|كبسولات|كبسول|سم)(?:\s*\/\s*\d+\s*(?:mg|ml|مجم|مل))?)/i;
    const m = normalizedDigitsText.match(doseRegex);
    if (m) {
      extractedDoseText = m[1].trim();
    }
  }

  // Detect explicit route keywords and check for route contradictions
  const hasOralTabKeyword = /(tablet|tablets|\btab\b|capsule|capsules|\bcap\b|\boral\b|قرص|أقراص|اقراص|كبسول|كبسولة|كبسولات|فموي)/i.test(text);
  const hasSuspensionKeyword = /(suspension|\bsyrup\b|شراب|معلق)/i.test(text);
  const hasInjectionKeyword = /(\bvial\b|ampoule|\bamp\b|injection|\biv\b|\bim\b|حقن|حقنة|أمبول|امبول|فيال|وريد|عضل)/i.test(text);
  const hasTopicalKeyword = /(\bcream\b|ointment|topical|\bgel\b|كريم|مرهم|موضعي|دهان)/i.test(text);

  const detectedRoutesCount = [
    hasOralTabKeyword,
    hasSuspensionKeyword,
    hasInjectionKeyword,
    hasTopicalKeyword,
  ].filter(Boolean).length;

  if (detectedRoutesCount > 1 && hasInjectionKeyword && (hasOralTabKeyword || hasSuspensionKeyword)) {
    contradictionWarnings.push(
      'تعارض في طريقة الإعطاء المستخرجة (ذُكر شكل فموي وحقن معاً في نفس النص) — يرجى التحقق من الروشتة.'
    );
  } else if (!extractedRoute) {
    if (hasInjectionKeyword) extractedRoute = 'injection';
    else if (hasSuspensionKeyword) extractedRoute = 'suspension';
    else if (hasTopicalKeyword) extractedRoute = 'topical';
    else if (hasOralTabKeyword) extractedRoute = 'oral';
  }

  // Detect explicit frequency patterns and check for conflicting frequencies
  const matchedFreqs = new Set<'once_daily' | 'twice_daily' | 'thrice_daily' | 'four_times_daily'>();
  if (/(once\s*daily|every\s*24\s*(?:h|hr|hours)|\bq\s*24\s*h\b|\bod\b|1\s*x\s*1|مرة\s*يوميا|مره\s*يوميا|مرة\s*واحدة\s*يوميا|كل\s*24\s*ساع)/i.test(text)) {
    matchedFreqs.add('once_daily');
  }
  if (/(twice\s*daily|every\s*12\s*(?:h|hr|hours)|\bq\s*12\s*h\b|\bbid\b|b\.i\.d|1\s*x\s*2|2\s*times\s*daily|مرتين\s*يوميا|كل\s*12\s*ساع)/i.test(text)) {
    matchedFreqs.add('twice_daily');
  }
  if (/(thrice\s*daily|three\s*times\s*daily|every\s*8\s*(?:h|hr|hours)|\bq\s*8\s*h\b|\btid\b|t\.i\.d|1\s*x\s*3|3\s*times\s*daily|3\s*مرات\s*يوميا|ثلاث\s*مرات\s*يوميا|كل\s*8\s*ساع)/i.test(text)) {
    matchedFreqs.add('thrice_daily');
  }
  if (/(four\s*times\s*daily|every\s*6\s*(?:h|hr|hours)|\bq\s*6\s*h\b|\bqid\b|q\.i\.d|1\s*x\s*4|4\s*times\s*daily|4\s*مرات\s*يوميا|أربع\s*مرات\s*يوميا|كل\s*6\s*ساع)/i.test(text)) {
    matchedFreqs.add('four_times_daily');
  }

  if (matchedFreqs.size > 1) {
    contradictionWarnings.push(
      'تعارض في عدد الجرعات اليومية المستخرجة (وُجد أكثر من تكرار زمني مختلف في النص) — يرجى المراجعة مع الطبيب أو الصيدلي.'
    );
    extractedFrequencyKey = '';
  } else if (!extractedFrequencyKey && matchedFreqs.size === 1) {
    extractedFrequencyKey = Array.from(matchedFreqs)[0];
  }

  // Detect explicit duration in days (e.g., "for 7 days", "x 5 days", "لمدة 7 أيام", "لمده 5 ايام")
  if (extractedDurationDays === null) {
    const normalizedDigitsText = text.replace(/[٠-٩]/g, (d) =>
      String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    );
    const durationMatches = Array.from(
      normalizedDigitsText.matchAll(
        /(?:for|x|duration|لمدة|لمده|مدة|كورس)\s*(\d{1,2})\s*(?:days?|d|أيام|ايام|يوم)|(\d{1,2})\s*(?:days?\s*course|أيام\s*كورس)/gi
      )
    );
    const distinctDays = new Set<number>();
    for (const dm of durationMatches) {
      const rawNum = dm[1] || dm[2];
      const n = parseInt(rawNum, 10);
      if (!isNaN(n) && n >= 1 && n <= 60) {
        distinctDays.add(n);
      }
    }
    if (distinctDays.size > 1) {
      contradictionWarnings.push(
        `تعارض في مدة العلاج المستخرجة (${Array.from(distinctDays).join(' مقابل ')} أيام) — يرجى التأكد من الطبيب أو الصيدلي.`
      );
    } else if (distinctDays.size === 1) {
      extractedDurationDays = Array.from(distinctDays)[0];
    }
  }

  // Detect co-medications if mentioned in prescription text
  if (/(panadol|paracetamol|\bcetal\b|abimol|باراسيتامول|بانادول|سيتال|أبيمول)/i.test(text)) {
    extractedCoMeds.push('paracetamol');
  }
  if (/(cataflam|brufen|voltaren|ketofan|ibuprofen|diclofenac|كتافلام|بروفين|فولتارين|كيتوفان)/i.test(text)) {
    extractedCoMeds.push('nsaids');
  }
  if (/(omeprazole|antodine|maalox|gaviscon|أوميبرازول|أنتودين|مالوكس|جافيسكون)/i.test(text)) {
    extractedCoMeds.push('antacids');
  }
  if (/(ferrotron|feroglobin|\biron\b|\bzinc\b|zinctron|فيروترون|حديد|زنك)/i.test(text)) {
    extractedCoMeds.push('iron_zinc');
  }
  if (/(osteocare|calcium|calcitron|أوستيوكير|كالسيوم)/i.test(text)) {
    extractedCoMeds.push('calcium_dairy');
  }
  if (/(lacteol|\blinex\b|probiotic|لاكتيول|لينكس|بروبيوتيك)/i.test(text)) {
    extractedCoMeds.push('probiotics');
  }
  if (/(marevan|warfarin|ماريفان|وارفارين)/i.test(text)) {
    extractedCoMeds.push('warfarin');
  }
  if (/(\bator\b|lipitor|\bzocor\b|statin|أتور|ليبيتور|زوكور)/i.test(text)) {
    extractedCoMeds.push('statins');
  }

  const unreadableFields: string[] = [];
  if (!detectedDrugName) unreadableFields.push('medicineName');
  if (!extractedDoseText) unreadableFields.push('prescribedDose');
  if (!extractedRoute) unreadableFields.push('route');
  if (!extractedFrequencyKey) unreadableFields.push('frequency');
  if (extractedDurationDays === null) unreadableFields.push('durationDays');

  return {
    detectedDrugName,
    matchedIngredientId,
    extractedDoseText,
    extractedRoute,
    extractedFrequencyKey,
    extractedFrequencyRaw,
    extractedDurationDays,
    extractedNotes,
    extractedCoMeds: Array.from(new Set(extractedCoMeds)),
    unreadableFields,
    contradictionWarnings,
    rawExtractedText: text,
    isUnverifiedOcr: true,
    autoApproved: false,
  };
}

/**
 * Extracts readable prescription details from an uploaded or camera-captured prescription/medicine image.
 * Downscales oversized images automatically for reliable Cloud & Local OCR, checks barcode,
 * strictly marks output as unverified (`isUnverifiedOcr: true`), never invents missing instructions,
 * and gracefully returns `unreadableFields` instead of throwing if OCR cannot read handwritten text.
 */
export async function analyzePrescriptionImageWithVision(
  base64Data: string,
  mimeType: string,
  lang: Lang,
  fileNameHint?: string
): Promise<PrescriptionOcrExtractionResult> {
  await ensureDawayaDatabaseLoaded().catch(() => {});
  const prepared = await prepareImageForOcrAndVision(base64Data, mimeType);
  const dataUri = prepared.dataUri;

  const prompt =
    lang === 'ar'
      ? `أنت صيدلي إكلينيكي مصري خبير في قراءة علب وشرائط الأدوية وفك خط الأطباء اليدوي في الروشتات المصرية.
انظر للصورة المرفوعة بدقة:
- إذا كانت الصورة لعلبة دواء أو شريط برشام أو عبوة: اقرأ الاسم التجاري المطبوع بخط رئيسي كبير على العلبة (Commercial Trade/Brand Name) مع التركيز والشكل الصيدلاني بدقة في خانة RX_DRUG_NAME. تحذير صارم: إياك أن تكتب اسم المادة الفعالة (Generic/Active Ingredient المكتوبة بخط أصغر تحت الاسم التجاري) في خانة RX_DRUG_NAME، بل ضع المادة الفعالة ودواعي الاستعمال داخل RX_NOTES فقط.
- إذا كانت الصورة لروشتة طبية مكتوبة بخط اليد أو مطبوعة: استخدم تخصص الطبيب والحروف الأولى والتركيز والشكل الصيدلاني لقراءة جميع الأدوية المكتوبة في الروشتة وافصل بينها بعلامة + في خانة RX_DRUG_NAME، واكتب الجرعات المكتوبة لكل دواء في RX_DOSE و RX_NOTES.
اكتب النتيجة بالصيغة التالية مباشرة بدون أقواس مربعة وبدون أمثلة:
RX_DRUG_ID: unknown
RX_DRUG_NAME: <الاسم التجاري للدواء المطبوع على العلبة مع التركيز، أو أسماء أدوية الروشتة مفصولة بعلامة +>
RX_DOSE: <التركيز والجرعة المقروءة من الصورة أو UNREADABLE>
RX_ROUTE: <oral أو suspension أو injection أو topical أو UNREADABLE>
RX_FREQ: <once_daily أو twice_daily أو thrice_daily أو four_times_daily أو UNREADABLE>
RX_DURATION_DAYS: <عدد أيام العلاج بالأرقام أو UNREADABLE>
RX_NOTES: <المادة الفعالة ودواعي الاستعمال أو قراءتك الكاملة لكل سطر في الروشتة بالتفصيل>
RX_CONTRADICTIONS: NONE`
      : `You are an expert Egyptian clinical pharmacist skilled at reading medicine boxes, blister strips, and handwritten Egyptian prescriptions.
- If the image is a medicine box, bottle, tube, or blister strip: put the exact COMMERCIAL TRADE/BRAND NAME and strength in RX_DRUG_NAME. CRITICAL: Never put the generic active ingredient (printed in smaller font under the brand name) in RX_DRUG_NAME; put the active ingredient in RX_NOTES instead.
- If the image is a medical prescription: list all prescribed medications separated by + in RX_DRUG_NAME.
Output the exact lines below without brackets:
RX_DRUG_ID: unknown
RX_DRUG_NAME: <commercial brand name and strength on the box, or prescription medications separated by +>
RX_DOSE: <dose and strength read from the image, or UNREADABLE>
RX_ROUTE: <oral, suspension, injection, topical, or UNREADABLE>
RX_FREQ: <once_daily, twice_daily, thrice_daily, four_times_daily, or UNREADABLE>
RX_DURATION_DAYS: <number of days or UNREADABLE>
RX_NOTES: <active ingredient and clinical summary, or full line-by-line reading of the prescription>
RX_CONTRADICTIONS: NONE`;

  const runGemini = async (): Promise<string> => {
    if (!hasApiKey()) return '';
    return await callServerAiProxy({
      prompt,
      inlineImageBase64: prepared.base64Data,
      mimeType: prepared.mimeType || 'image/jpeg',
    });
  };

  const [geminiRes, cloudOcrRes, zeroHintRes] = await Promise.allSettled([
    runGemini(),
    runCloudOcrNonColliding(dataUri),
    runZeroHintVisionOcr(dataUri),
  ]);

  const geminiText = geminiRes.status === 'fulfilled' ? geminiRes.value : '';
  const cloudOcrText = cloudOcrRes.status === 'fulfilled' ? cloudOcrRes.value : '';
  const zeroHintText = zeroHintRes.status === 'fulfilled' ? zeroHintRes.value : '';

  let combinedRaw = [
    prepared.nativeBarcode || '',
    geminiText,
    cloudOcrText,
    zeroHintText,
  ]
    .filter(Boolean)
    .join('\n')
    .trim();

  let parsedResult = parsePrescriptionTextDeterministically(combinedRaw);

  // Run local Tesseract OCR if no drug name was detected OR if only a generic active ingredient was returned
  if (!parsedResult.detectedDrugName || isPureGenericIngredientQuery(parsedResult.detectedDrugName)) {
    const localTesseract = await performBrowserTesseractOcr(dataUri);
    if (localTesseract) {
      const boxBrandHit = findDawayaIndexItemSync(`${localTesseract}\n${parsedResult.detectedDrugName}\n${parsedResult.extractedDoseText}`);
      if (boxBrandHit) {
        parsedResult.detectedDrugName = boxBrandHit.a ? `${boxBrandHit.a} (${boxBrandHit.n})` : boxBrandHit.n;
        parsedResult.matchedIngredientId = boxBrandHit.i;
        parsedResult.unreadableFields = parsedResult.unreadableFields.filter((f) => f !== 'medicineName');
      } else if (!parsedResult.detectedDrugName) {
        combinedRaw = [combinedRaw, localTesseract].filter(Boolean).join('\n').trim();
        parsedResult = parsePrescriptionTextDeterministically(combinedRaw);
      }
    }
  }

  return parsedResult;
}
