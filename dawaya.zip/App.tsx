import { DawayaIconMark } from './DawayaLogo';
import DawayaErrorBoundary from './ErrorBoundary';
import { ComponentType, lazy, Suspense, useEffect } from 'react';
import { Route, Routes, Link } from 'react-router-dom';
import { configured } from './firebase';
import { useLang } from './i18n';
import Layout from './Layout';
import { AuthProvider } from './authContext';
import { EmergencyLocationProvider } from './emergencyLocation';
import AuthModal from './AuthModal';
import Home from './Home';
import { startPartnerEcosystemSync } from './partnerService';

/**
 * Offline-safe & OTA-safe lazy loader.
 * Splits the bundle into small chunks for 5x faster initial startup while avoiding infinite reload loops when offline.
 */
function lazyWithRetry<T extends ComponentType<any>>(
  factory: () => Promise<{ default: T }>
) {
  return lazy(() =>
    factory().catch((err) => {
      if (typeof navigator !== 'undefined' && navigator.onLine !== false) {
        const key = 'aa_chunk_retry_reloaded';
        const hasReloaded = sessionStorage.getItem(key) === '1';
        if (!hasReloaded) {
          sessionStorage.setItem(key, '1');
          window.location.reload();
          return new Promise<{ default: T }>(() => {});
        }
        sessionStorage.removeItem(key);
      }
      throw err;
    })
  );
}

// Lazy-loaded clinical tools, directories & pages
const HomeMedicineCabinet = lazyWithRetry(() => import('./HomeMedicineCabinet'));
const RamadanFastingClock = lazyWithRetry(() => import('./RamadanFastingClock'));
const TravelMedKit = lazyWithRetry(() => import('./TravelMedKit'));
import PatientDashboard from './PatientDashboard';
const OneClickCheckup = lazyWithRetry(() => import('./OneClickCheckup'));
const PrescriptionRadar = lazyWithRetry(() => import('./PrescriptionRadar'));
const AwarenessWeek = lazyWithRetry(() => import('./AwarenessWeek'));
const GreenPrescription = lazyWithRetry(() => import('./GreenPrescription'));
const CompareDrugs = lazyWithRetry(() => import('./CompareDrugs'));
const SafeDisposal = lazyWithRetry(() => import('./SafeDisposal'));
import PediatricHelper from './PediatricHelper';
import HealthProfile from './HealthProfile';
const AllergyChecker = lazyWithRetry(() => import('./AllergyChecker'));
const ListenLearn = lazyWithRetry(() => import('./ListenLearn'));
import Tracker from './Tracker';
const SideEffectsGuide = lazyWithRetry(() => import('./SideEffectsGuide'));
const Interactions = lazyWithRetry(() => import('./Interactions'));
import CostSaver from './CostSaver';
const ColdShotWarning = lazyWithRetry(() => import('./ColdShotWarning'));
const DailyScheduleGenerator = lazyWithRetry(() => import('./DailyScheduleGenerator'));
const SmartPassport = lazyWithRetry(() => import('./SmartPassport'));
const PassportView = lazyWithRetry(() => import('./PassportView'));
import Medicines from './Medicines';
import MedicinePage from './MedicinePage';
const Articles = lazyWithRetry(() => import('./Articles'));
const ArticlePage = lazyWithRetry(() =>
  import('./Articles').then((m) => ({ default: m.ArticlePage }))
);
const Quiz = lazyWithRetry(() => import('./Quiz'));
import Scan from './Scan';
const Learn = lazyWithRetry(() => import('./Learn'));
import Assistant from './Assistant';
const MythFact = lazyWithRetry(() => import('./MythFact'));
import ClinicalNutritionClinic from './ClinicalNutritionClinic';
import WomensHealthClinic from './WomensHealthClinic';
import GeriatricCareClinic from './GeriatricCareClinic';
import HairSkincareClinic from './HairSkincareClinic';
import ChestRespiratoryClinic from './ChestRespiratoryClinic';
import InteractiveBodyMap from './InteractiveBodyMap';
const FoodDrugInteractionChecker = lazyWithRetry(() => import('./FoodDrugInteractionChecker'));
const SmartLabAndRxPhotoScanner = lazyWithRetry(() => import('./SmartLabAndRxPhotoScanner'));
const VisualBodyDrugSimulator = lazyWithRetry(() => import('./VisualBodyDrugSimulator'));
const ChronicMealPlanner = lazyWithRetry(() => import('./ChronicMealPlanner'));
const ComprehensiveMedicalReport = lazyWithRetry(() => import('./ComprehensiveMedicalReport'));
const MissedDoseRescueSolver = lazyWithRetry(() => import('./MissedDoseRescueSolver'));
const DoctorVisitPrep = lazyWithRetry(() => import('./DoctorVisitPrep'));
const EgyptianVaccineTracker = lazyWithRetry(() => import('./EgyptianVaccineTracker'));

import SmartSymptomTriage from './SmartSymptomTriage';
import OphthalmologyClinic from './OphthalmologyClinic';
import EntClinic from './EntClinic';
import LabTestDecoderClinic from './LabTestDecoderClinic';
import UrologyRenalClinic from './UrologyRenalClinic';
import NeurologyClinic from './NeurologyClinic';
import PoisonFirstAidClinic from './PoisonFirstAidClinic';
import SpecialtyClinicsHub from './SpecialtyClinicsHub';
import OrthopedicsClinic from './OrthopedicsClinic';
import GastroClinic from './GastroClinic';
import DermatologyClinic from './DermatologyClinic';
import DentalEmergencyClinic from './DentalEmergencyClinic';
import G6pdFavismClinic from './G6pdFavismClinic';
import ChronicCareClinic from './ChronicCareClinic';
import NewbornFirstYearGuide from './NewbornFirstYearGuide';
import PregnancySafetyNavigator from './PregnancySafetyNavigator';
const AirportBannedMedsScanner = lazyWithRetry(() => import('./AirportBannedMedsScanner'));
const BabyMilkFormulaNavigator = lazyWithRetry(() => import('./BabyMilkFormulaNavigator'));
const SeniorPillVisualIdentifier = lazyWithRetry(() => import('./SeniorPillVisualIdentifier'));
const SteroidTaperingCalendar = lazyWithRetry(() => import('./SteroidTaperingCalendar'));
const HypoRescuePlan = lazyWithRetry(() => import('./HypoRescuePlan'));
const InhalerDoseCounter = lazyWithRetry(() => import('./InhalerDoseCounter'));
const Methodology = lazyWithRetry(() => import('./Methodology'));
const Research = lazyWithRetry(() => import('./Research'));
const Dashboard = lazyWithRetry(() => import('./Dashboard'));
const Editor = lazyWithRetry(() => import('./Editor'));
const PartnersDirectoryPage = lazyWithRetry(() => import('./PartnersDirectory'));
const PharmacyOwnerDashboard = lazyWithRetry(() => import('./PharmacyOwnerDashboard'));
const PartnerPublicProfilePage = lazyWithRetry(() =>
  import('./PartnersDirectory').then((m) => ({ default: m.PartnerPublicProfilePage }))
);

// Lazy-loaded 2D & 3D WebGL Games (keeps Three.js 650KB out of the initial startup bundle)
const GameCenter = lazyWithRetry(() => import('./GameCenter'));
const BacteriaHunter = lazyWithRetry(() => import('./BacteriaHunter'));
const OpenWorldGame = lazyWithRetry(() => import('./OpenWorldGame'));
const MedicalSimulator = lazyWithRetry(() => import('./MedicalSimulator'));
const NurseAcademy = lazyWithRetry(() => import('./NurseAcademy'));
const MedicalMystery = lazyWithRetry(() => import('./MedicalMystery'));
const BacteriaLab = lazyWithRetry(() => import('./BacteriaLab'));
const EmergencyShift = lazyWithRetry(() => import('./EmergencyShift'));
const EscapeTheLab = lazyWithRetry(() => import('./EscapeTheLab'));

function ConfigMissing() {
  const { t } = useLang();
  return (
    <main className="wrap narrow">
      <div className="card">
        <h1>Firebase is not configured</h1>
        <p>
          Copy <code>.env.example</code> to <code>.env.local</code>, paste your Firebase web app values, then restart{' '}
          <code>npm run dev</code>.
        </p>
        <p dir="rtl">
          لوحة الإدارة تتطلب إعدادات Firebase. انسخ الملف <code>.env.example</code> إلى <code>.env.local</code> وأدخل القيم ثم أعد التشغيل.
        </p>
        <p style={{ marginTop: '1rem' }}>
          <Link to="/" className="btn">{t('navHome')}</Link>
        </p>
      </div>
    </main>
  );
}

function PageLoadingFallback() {
  const { lang } = useLang();
  const isAr = lang === 'ar';
  return (
    <main className="wrap narrow" dir={isAr ? 'rtl' : 'ltr'}>
      <div
        className="card center stack"
        style={{
          padding: '32px 22px',
          background: 'radial-gradient(circle at 50% 25%, #132B4C 0%, #0D1F38 70%)',
          border: '2px solid rgba(36, 200, 184, 0.45)',
          borderRadius: '26px',
          color: '#ffffff',
          alignItems: 'center',
          gap: '14px',
          boxShadow: '0 18px 40px rgba(13, 31, 56, 0.32)',
        }}
      >
        <div
          style={{
            padding: '7px',
            borderRadius: '50%',
            background: 'rgba(19, 136, 102, 0.22)',
            border: '2px solid rgba(36, 200, 184, 0.65)',
            boxShadow: '0 0 28px rgba(0, 191, 208, 0.35)',
          }}
        >
          <DawayaIconMark size={76} />
        </div>
        <div style={{ fontWeight: 800, fontSize: '1.3rem', letterSpacing: '0.02em', direction: 'ltr' }}>
          DAWAYA | دوايا
        </div>
        <div
          style={{
            padding: '12px 20px',
            borderRadius: '999px',
            background: 'rgba(255, 255, 255, 0.10)',
            border: '1.8px solid #D2D1A3',
            boxShadow: '0 0 20px rgba(210, 209, 163, 0.2)',
            fontWeight: 700,
            fontSize: '1.08rem',
            color: '#ffffff',
          }}
        >
          اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّد ﷺ
        </div>
        <span style={{ fontSize: '0.88rem', color: '#CBD5E1' }}>
          {isAr ? 'صحتك.. بذكاء أكتر' : 'Your Health. Smarter.'}
        </span>
      </div>
    </main>
  );
}

function SimulatorLoadingFallback() {
  const { lang } = useLang();
  const isAr = lang === 'ar';
  return (
    <main className="wrap narrow" dir={isAr ? 'rtl' : 'ltr'}>
      <div className="card center" style={{ padding: '42px 20px' }}>
        <div style={{ fontSize: '2.4rem', marginBottom: '10px' }} aria-hidden="true">🏥</div>
        <h2 style={{ marginBottom: '6px' }}>
          {isAr ? 'جارٍ تجهيز المشهد التفاعلي ثلاثي الأبعاد (3D)...' : 'Loading 3D Interactive Game Scene...'}
        </h2>
        <p className="small muted" style={{ margin: 0 }}>
          {isAr
            ? 'يتم الآن تحميل المشهد ثلاثي الأبعاد والشخصيات والمحطات التفاعلية.'
            : 'Initializing WebGL 3D scene, cartoon avatars, and interactive stations.'}
        </p>
      </div>
    </main>
  );
}

function NotFound() {
  const { t } = useLang();
  return (
    <main className="wrap narrow">
      <p>{t('notFound')}</p>
      <Link to="/">{t('navHome')}</Link>
    </main>
  );
}

export default function App() {
  useEffect(() => {
    // Lightweight startup: sync public partners after idle without downloading 8.2MB index until needed
    const timer = window.setTimeout(() => {
      startPartnerEcosystemSync();
    }, 1500);
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <AuthProvider>
      <EmergencyLocationProvider>
        <Layout>
          <DawayaErrorBoundary>
            <Suspense fallback={<PageLoadingFallback />}>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/patient-dashboard" element={<PatientDashboard />} />
                <Route path="/dashboard" element={<PatientDashboard />} />
                <Route path="/medicines" element={<Medicines />} />
                <Route path="/partners" element={<PartnersDirectoryPage />} />
                <Route path="/pharmacies" element={<PartnersDirectoryPage />} />
                <Route path="/pharmacy-portal" element={<PharmacyOwnerDashboard />} />
                <Route path="/pharmacy-dashboard" element={<PharmacyOwnerDashboard />} />
                <Route path="/partner/:id" element={<PartnerPublicProfilePage />} />
                <Route path="/cost-saver" element={<CostSaver />} />
                <Route path="/cold-shot-warning" element={<ColdShotWarning />} />
                <Route path="/home-cabinet" element={<HomeMedicineCabinet />} />
                <Route path="/cabinet" element={<HomeMedicineCabinet />} />
                <Route path="/ramadan-clock" element={<RamadanFastingClock />} />
                <Route path="/fasting-clock" element={<RamadanFastingClock />} />
                <Route path="/travel-kit" element={<TravelMedKit />} />
                <Route path="/travel" element={<TravelMedKit />} />
                <Route path="/daily-schedule" element={<DailyScheduleGenerator />} />
                <Route path="/green-prescription" element={<GreenPrescription />} />
                <Route path="/awareness-week" element={<AwarenessWeek />} />
                <Route path="/compare" element={<CompareDrugs />} />
                <Route path="/complete-checkup" element={<OneClickCheckup />} />
                <Route path="/prescription-radar" element={<PrescriptionRadar />} />
                <Route path="/interactions" element={<Interactions />} />
                <Route path="/safe-disposal" element={<SafeDisposal />} />
                <Route path="/tracker" element={<Tracker />} />
                <Route path="/side-effects" element={<SideEffectsGuide />} />
                <Route path="/listen" element={<ListenLearn />} />
                <Route path="/health-profile" element={<HealthProfile />} />
                <Route path="/allergy-checker" element={<AllergyChecker />} />
                <Route path="/pediatric-helper" element={<PediatricHelper />} />
                <Route path="/medicine/:id" element={<MedicinePage />} />
                <Route path="/articles" element={<Articles />} />
                <Route path="/articles/:id" element={<ArticlePage />} />
                <Route path="/quiz" element={<Quiz />} />
                <Route path="/scan" element={<Scan />} />
                <Route path="/learn" element={<Learn />} />
                <Route path="/assistant" element={<Assistant />} />
                <Route path="/myth" element={<MythFact />} />
                <Route path="/methodology" element={<Methodology />} />
                <Route path="/research" element={<Research />} />
                <Route path="/nutrition-clinic" element={<ClinicalNutritionClinic />} />
                <Route path="/women-clinic" element={<WomensHealthClinic />} />
                <Route path="/geriatric-clinic" element={<GeriatricCareClinic />} />
                <Route path="/hair-clinic" element={<HairSkincareClinic />} />
                <Route path="/chest-clinic" element={<ChestRespiratoryClinic />} />
                <Route path="/body-map" element={<InteractiveBodyMap />} />
                <Route path="/food-drug-checker" element={<FoodDrugInteractionChecker />} />
                <Route path="/lab-photo-scanner" element={<SmartLabAndRxPhotoScanner />} />
                <Route path="/organ-simulator" element={<VisualBodyDrugSimulator />} />
                <Route path="/meal-planner" element={<ChronicMealPlanner />} />
                <Route path="/medical-report" element={<ComprehensiveMedicalReport />} />
                <Route path="/missed-dose-rescue" element={<MissedDoseRescueSolver />} />
                <Route path="/missed-dose" element={<MissedDoseRescueSolver />} />
                <Route path="/doctor-visit-prep" element={<DoctorVisitPrep />} />
                <Route path="/doctor-prep" element={<DoctorVisitPrep />} />
                <Route path="/vaccine-tracker" element={<EgyptianVaccineTracker />} />
                <Route path="/vaccines" element={<EgyptianVaccineTracker />} />
                <Route path="/symptom-triage" element={<SmartSymptomTriage />} />
                <Route path="/eye-clinic" element={<OphthalmologyClinic />} />
                <Route path="/ent-clinic" element={<EntClinic />} />
                <Route path="/lab-clinic" element={<LabTestDecoderClinic />} />
                <Route path="/urology-clinic" element={<UrologyRenalClinic />} />
                <Route path="/neuro-clinic" element={<NeurologyClinic />} />
                <Route path="/poison-clinic" element={<PoisonFirstAidClinic />} />
                <Route path="/clinics" element={<SpecialtyClinicsHub />} />
                <Route path="/specialty-clinics" element={<SpecialtyClinicsHub />} />
                <Route path="/ortho-clinic" element={<OrthopedicsClinic />} />
                <Route path="/gastro-clinic" element={<GastroClinic />} />
                <Route path="/derma-clinic" element={<DermatologyClinic />} />
                <Route path="/dental-clinic" element={<DentalEmergencyClinic />} />
                <Route path="/g6pd-clinic" element={<G6pdFavismClinic />} />
                <Route path="/chronic-clinic" element={<ChronicCareClinic />} />
                <Route path="/baby-first-year" element={<NewbornFirstYearGuide />} />
                <Route path="/newborn-guide" element={<NewbornFirstYearGuide />} />
                <Route path="/infant-care" element={<NewbornFirstYearGuide />} />
                <Route path="/pregnancy-guide" element={<PregnancySafetyNavigator />} />
                <Route path="/pregnancy" element={<PregnancySafetyNavigator />} />
                <Route path="/pregnant" element={<PregnancySafetyNavigator />} />
                <Route path="/airport-banned-meds" element={<AirportBannedMedsScanner />} />
                <Route path="/banned-meds" element={<AirportBannedMedsScanner />} />
                <Route path="/baby-milk" element={<BabyMilkFormulaNavigator />} />
                <Route path="/milk-formula" element={<BabyMilkFormulaNavigator />} />
                <Route path="/senior-pills" element={<SeniorPillVisualIdentifier />} />
                <Route path="/pill-identifier" element={<SeniorPillVisualIdentifier />} />
                <Route path="/steroid-taper" element={<SteroidTaperingCalendar />} />
                <Route path="/cortisone-taper" element={<SteroidTaperingCalendar />} />
                <Route path="/hypo-rescue" element={<HypoRescuePlan />} />
                <Route path="/hypoglycemia-rescue" element={<HypoRescuePlan />} />
                <Route path="/inhaler-counter" element={<InhalerDoseCounter />} />
                <Route path="/asthma-counter" element={<InhalerDoseCounter />} />
                <Route path="/games" element={<GameCenter />} />
                <Route
                  path="/open-world"
                  element={
                    <Suspense fallback={<SimulatorLoadingFallback />}>
                      <OpenWorldGame />
                    </Suspense>
                  }
                />
                <Route
                  path="/medical-simulator"
                  element={
                    <Suspense fallback={<SimulatorLoadingFallback />}>
                      <MedicalSimulator />
                    </Suspense>
                  }
                />
                <Route
                  path="/nurse-academy"
                  element={
                    <Suspense fallback={<SimulatorLoadingFallback />}>
                      <NurseAcademy />
                    </Suspense>
                  }
                />
                <Route
                  path="/medical-mystery"
                  element={
                    <Suspense fallback={<SimulatorLoadingFallback />}>
                      <MedicalMystery />
                    </Suspense>
                  }
                />
                <Route
                  path="/bacteria-lab"
                  element={
                    <Suspense fallback={<SimulatorLoadingFallback />}>
                      <BacteriaLab />
                    </Suspense>
                  }
                />
                <Route
                  path="/emergency-shift"
                  element={
                    <Suspense fallback={<SimulatorLoadingFallback />}>
                      <EmergencyShift />
                    </Suspense>
                  }
                />
                <Route
                  path="/escape-the-lab"
                  element={
                    <Suspense fallback={<SimulatorLoadingFallback />}>
                      <EscapeTheLab />
                    </Suspense>
                  }
                />
                <Route path="/game" element={<BacteriaHunter />} />
                <Route path="/admin" element={configured ? <Dashboard /> : <ConfigMissing />} />
                <Route path="/admin/new" element={configured ? <Editor /> : <ConfigMissing />} />
                <Route path="/admin/medicine/:id" element={configured ? <Editor /> : <ConfigMissing />} />
                <Route path="/passport" element={<SmartPassport />} />
                <Route path="/smart-passport" element={<SmartPassport />} />
                <Route path="/passport/:uid" element={<PassportView />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
          </DawayaErrorBoundary>
        </Layout>
        <AuthModal />
      </EmergencyLocationProvider>
    </AuthProvider>
  );
}
