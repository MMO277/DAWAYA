import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
  signInWithPopup,
  reauthenticateWithPopup,
  signInWithCredential,
  GoogleAuthProvider,
  browserPopupRedirectResolver,
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, configured } from './firebase';

export type AuthMode = 'login' | 'register' | 'forgot';
export type Role =
  | 'owner'
  | 'super_admin'
  | 'admin'
  | 'regional_manager'
  | 'reviewer'
  | 'editor'
  | 'pharmacy_owner'
  | 'pharmacy_manager'
  | 'pharmacist'
  | 'employee'
  | 'viewer'
  | 'customer'
  | 'user';

export const ROLES: Role[] = [
  'owner',
  'super_admin',
  'admin',
  'regional_manager',
  'reviewer',
  'editor',
  'pharmacy_owner',
  'pharmacy_manager',
  'pharmacist',
  'employee',
  'viewer',
  'customer',
];

export const STAFF_ADMIN_ROLES: Role[] = [
  'owner',
  'super_admin',
  'admin',
  'regional_manager',
  'reviewer',
  'editor',
  'pharmacy_owner',
  'pharmacy_manager',
  'pharmacist',
  'employee',
  'viewer',
];

export function isStaffOrAdminRole(role: Role | null | undefined): boolean {
  if (!role || role === 'customer' || role === 'user') return false;
  return STAFF_ADMIN_ROLES.includes(role);
}

export const GUEST_MODE_KEY = 'aa_guest_mode';
const ROLE_CACHE_PREFIX = 'aa_cached_role_';
export const SAVED_GOOGLE_ACCOUNTS_KEY = 'aa_saved_google_accounts_v1';

export interface SavedGoogleAccount {
  email: string;
  displayName: string;
  uid: string;
  photoURL?: string | null;
  lastUsedAt: number;
}

/**
 * Resolves a real Google Account Profile Photo URL for any Google email.
 */
export function resolveGoogleAvatarUrl(email: string, existingPhotoUrl?: string | null): string {
  if (
    existingPhotoUrl &&
    (existingPhotoUrl.startsWith('http://') ||
      existingPhotoUrl.startsWith('https://') ||
      existingPhotoUrl.startsWith('data:'))
  ) {
    return existingPhotoUrl;
  }
  const cleanEmail = (email || '').trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes('@')) return '';
  return `https://unavatar.io/google/${encodeURIComponent(cleanEmail)}`;
}

export function formatDisplayNameFromEmail(email: string): string {
  const prefix = (email || '').split('@')[0] || 'Google User';
  const cleaned = prefix
    .replace(/[._-]+/g, ' ')
    .replace(/\d+$/g, '')
    .trim();
  if (!cleaned) return prefix;
  return cleaned
    .split(' ')
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

// Section 2 Security Fix: Removed deterministic email-derived password generation (computeFirebaseAppBridgeSecret)
// and public Firestore OAuth token bridge (getEmailBridgeDocId). Authentication strictly uses standard Firebase Auth.

export function getSavedDeviceGoogleAccounts(): SavedGoogleAccount[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(SAVED_GOOGLE_ACCOUNTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed
          .filter(
            (a) =>
              a &&
              typeof a.email === 'string' &&
              a.email.includes('@') &&
              typeof a.uid === 'string' &&
              !a.uid.startsWith('g_') &&
              !a.uid.startsWith('google_')
          )
          .map((a) => ({
            ...a,
            displayName: a.displayName || formatDisplayNameFromEmail(a.email),
            photoURL: resolveGoogleAvatarUrl(a.email, a.photoURL),
          }));
      }
    }
  } catch {
    /* ignore */
  }
  return [];
}

export function saveDeviceGoogleAccount(account: SavedGoogleAccount): void {
  if (typeof window === 'undefined') return;
  try {
    const cleanEmail = account.email.trim().toLowerCase();
    const existingList = getSavedDeviceGoogleAccounts();
    const prevMatch = existingList.find((a) => a.email.toLowerCase() === cleanEmail);

    const mergedAccount: SavedGoogleAccount = {
      email: cleanEmail,
      displayName:
        account.displayName?.trim() ||
        prevMatch?.displayName ||
        formatDisplayNameFromEmail(cleanEmail),
      uid: account.uid || prevMatch?.uid || '',
      photoURL: resolveGoogleAvatarUrl(cleanEmail, account.photoURL || prevMatch?.photoURL),
      lastUsedAt: Date.now(),
    };

    if (!mergedAccount.uid) return;

    const others = existingList.filter((a) => a.email.toLowerCase() !== cleanEmail);
    const updated = [mergedAccount, ...others].slice(0, 8);
    localStorage.setItem(SAVED_GOOGLE_ACCOUNTS_KEY, JSON.stringify(updated));
  } catch {
    /* ignore */
  }
}

export function removeSavedDeviceGoogleAccount(email: string): void {
  if (typeof window === 'undefined') return;
  try {
    const clean = email.trim().toLowerCase();
    const filtered = getSavedDeviceGoogleAccounts().filter(
      (a) => a.email.toLowerCase() !== clean
    );
    localStorage.setItem(SAVED_GOOGLE_ACCOUNTS_KEY, JSON.stringify(filtered));
  } catch {
    /* ignore */
  }
}

export async function fetchCloudSyncedGoogleAccounts(): Promise<SavedGoogleAccount[]> {
  // Strictly return accounts saved on THIS device only (never leak global accounts across visitors)
  return getSavedDeviceGoogleAccounts();
}

export function isGuestModeActive(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    if (
      sessionStorage.getItem(GUEST_MODE_KEY) === '1' ||
      localStorage.getItem(GUEST_MODE_KEY) === '1'
    ) {
      return true;
    }
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

export function setGuestModeActive(active: boolean): void {
  if (typeof window === 'undefined') return;
  try {
    if (active) {
      sessionStorage.setItem(GUEST_MODE_KEY, '1');
      localStorage.setItem(GUEST_MODE_KEY, '1');
    } else {
      sessionStorage.removeItem(GUEST_MODE_KEY);
      localStorage.removeItem(GUEST_MODE_KEY);
    }
  } catch {}
}

export interface NativePickedGoogleProfile {
  email: string;
  displayName?: string;
  photoURL?: string;
  idToken?: string;
  accessToken?: string;
  uid?: string;
}

export interface AuthContextType {
  user: User | null;
  role: Role | null;
  roleStatus: string;
  loading: boolean;
  error: string | null;
  clearError: () => void;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<void>;
  register: (email: string, password: string, displayName?: string, rememberMe?: boolean) => Promise<void>;
  loginWithGoogle: (loginHintEmail?: string) => Promise<void>;
  loginWithNativeGoogleAccount: (profile: NativePickedGoogleProfile) => Promise<void>;
  activateAppBridgeNow: (hintEmail?: string) => Promise<boolean>;
  needsAppBridgeActivation: boolean;
  hasNativeGoogleAccountPicker: () => boolean;
  triggerNativeGoogleAccountPicker: () => Promise<string | null>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  modalOpen: boolean;
  modalMode: AuthMode;
  openAuthModal: (mode?: AuthMode) => void;
  closeAuthModal: () => void;
  logoutModalOpen: boolean;
  openLogoutModal: () => void;
  closeLogoutModal: () => void;
  isGuest: boolean;
  continueAsGuest: () => void;
  exitGuestMode: () => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  role: null,
  roleStatus: '',
  loading: false,
  error: null,
  clearError: () => {},
  login: async () => {},
  register: async () => {},
  loginWithGoogle: async () => {},
  loginWithNativeGoogleAccount: async () => {},
  activateAppBridgeNow: async () => false,
  needsAppBridgeActivation: false,
  hasNativeGoogleAccountPicker: () => false,
  triggerNativeGoogleAccountPicker: async () => null,
  logout: async () => {},
  resetPassword: async () => {},
  modalOpen: false,
  modalMode: 'login',
  openAuthModal: () => {},
  closeAuthModal: () => {},
  logoutModalOpen: false,
  openLogoutModal: () => {},
  closeLogoutModal: () => {},
  isGuest: false,
  continueAsGuest: () => {},
  exitGuestMode: () => {},
});

export const useAuth = () => useContext(AuthContext);

export function translateAuthError(errCode: string, isAr = true): string {
  switch (errCode) {
    case 'auth/unconfigured':
      return isAr
        ? 'خدمة الحسابات السحابية غير مفعّلة في هذه النسخة (إعدادات Firebase غير متوفرة). يمكنك الاستمرار في استخدام كافة أدوات الموقع كزائر بكل أمان.'
        : 'Cloud accounts are not configured in this build. You can safely continue using all platform features as a guest.';
    case 'auth/invalid-email':
      return isAr ? 'صيغة البريد الإلكتروني غير صحيحة.' : 'Invalid email address format.';
    case 'auth/user-not-found':
      return isAr ? 'لم يتم العثور على حساب مسجل بهذا البريد الإلكتروني.' : 'No account found with this email.';
    case 'auth/client-rate-locked':
      return isAr
        ? '🛡️ تم إيقاف المحاولات مؤقتاً لمدة 30 ثانية لحماية الحساب من التخمين المتكرر. يرجى الانتظار قليلاً ثم المحاولة.'
        : '🛡️ Too many failed attempts. Locked for 30 seconds to protect your account.';
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return isAr ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' : 'Incorrect email or password.';
    case 'auth/email-already-in-use':
      return isAr ? 'هذا البريد الإلكتروني مسجل بالفعل. يرجى تسجيل الدخول بدلاً من ذلك.' : 'This email is already registered. Please sign in instead.';
    case 'auth/weak-password':
      return isAr ? 'كلمة المرور ضعيفة. يُرجى استخدام 6 أحرف أو أرقام على الأقل.' : 'Password is too weak. Please use at least 6 characters.';
    case 'auth/too-many-requests':
      return isAr ? 'تم حظر المحاولات مؤقتاً لتكرار المحاولات الخاطئة. انتظر دقيقة ثم أعد المحاولة.' : 'Too many unsuccessful attempts. Please wait a minute and try again.';
    case 'auth/network-request-failed':
      return isAr ? 'أنت الآن في وضع الأوفلاين (بدون إنترنت). يمكنك الضغط على "متابعة التصفح كزائر" لاستخدام كافة أدوات التطبيق فوراً بدون إنترنت!' : 'You are currently offline. Tap "Continue as Guest" to use all platform features offline immediately!';
    case 'auth/requires-recent-login':
      return isAr ? 'يجب إعادة تسجيل الدخول لتنفيذ هذا الإجراء الأمني.' : 'Please log in again to confirm this sensitive action.';
    case 'auth/popup-closed-by-user':
      return isAr ? 'تم إغلاق نافذة اختيار الحساب.' : 'Account selector was closed.';
    case 'auth/popup-blocked':
      return isAr ? 'المتصفح منع النافذة المنبثقة. يرجى السماح بالنوافذ المنبثقة.' : 'Popup was blocked by the browser. Please allow popups.';
    case 'auth/needs-one-time-web-bridge':
      return isAr
        ? 'لتشغيل نفس حسابك المسجل على الموقع داخل التطبيق بدون باسورد، اضغط الزر الأخضر بالأسفل لتأكيده بضغطة واحدة فقط.'
        : 'To use your exact website Google account inside the app without a password, tap the green button below once.';
    default:
      return isAr ? 'حدث خطأ في المصادقة. يُرجى إعادة المحاولة.' : 'Authentication error occurred. Please try again.';
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<Role | null>(null);
  const [roleStatus, setRoleStatus] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isGuest, setIsGuest] = useState<boolean>(() => true);
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [modalMode, setModalMode] = useState<AuthMode>('login');
  const [logoutModalOpen, setLogoutModalOpen] = useState(false);
  const [needsAppBridgeActivation, setNeedsAppBridgeActivation] = useState(false);

  useEffect(() => {
    try {
      localStorage.removeItem('aa_quick_google_user_v1');
      const rawTrusted = localStorage.getItem('dawaya_trusted_android_user_v1');
      if (rawTrusted) {
        const parsed = JSON.parse(rawTrusted);
        if (!parsed?.uid || String(parsed.uid).startsWith('google_') || String(parsed.uid).startsWith('g_')) {
          localStorage.removeItem('dawaya_trusted_android_user_v1');
        }
      }
    } catch {}
  }, []);

  const syncGoogleBridgeToFirestore = async (
    firebaseUser: User,
    _oauthIdToken?: string | null,
    _oauthAccessToken?: string | null
  ): Promise<boolean> => {
    const email = firebaseUser.email?.trim().toLowerCase();
    if (!email) return false;

    const googlePhoto =
      firebaseUser.photoURL ||
      firebaseUser.providerData?.find((p) => p?.photoURL)?.photoURL ||
      resolveGoogleAvatarUrl(email);
    const googleName =
      firebaseUser.displayName ||
      firebaseUser.providerData?.find((p) => p?.displayName)?.displayName ||
      formatDisplayNameFromEmail(email);

    setNeedsAppBridgeActivation(false);

    // Save non-sensitive display metadata locally on this device only (never derive passwords or store tokens in Firestore)
    saveDeviceGoogleAccount({
      email,
      displayName: googleName,
      uid: firebaseUser.uid,
      photoURL: googlePhoto,
      lastUsedAt: Date.now(),
    });

    if (configured && db && firebaseUser.uid) {
      setDoc(
        doc(db, 'customerProfiles', firebaseUser.uid),
        {
          uid: firebaseUser.uid,
          email,
          displayName: googleName,
          photoURL: googlePhoto,
          lastLoginAt: new Date().toISOString(),
        },
        { merge: true }
      ).catch(() => {});
    }

    return true;
  };

  const activateAppBridgeNow = async (hintEmail?: string): Promise<boolean> => {
    if (!configured || !auth) return false;
    try {
      await setPersistence(auth, browserLocalPersistence);
      const provider = new GoogleAuthProvider();
      const targetEmail = hintEmail || auth.currentUser?.email || '';
      if (targetEmail) {
        provider.setCustomParameters({ login_hint: targetEmail.trim().toLowerCase() });
      } else {
        provider.setCustomParameters({ prompt: 'select_account' });
      }

      let cred;
      if (auth.currentUser && (!hintEmail || auth.currentUser.email?.toLowerCase() === hintEmail.toLowerCase())) {
        try {
          cred = await reauthenticateWithPopup(auth.currentUser, provider, browserPopupRedirectResolver);
        } catch {
          cred = await signInWithPopup(auth, provider, browserPopupRedirectResolver);
        }
      } else {
        cred = await signInWithPopup(auth, provider, browserPopupRedirectResolver);
      }

      const oauthCred = GoogleAuthProvider.credentialFromResult(cred);
      if (cred.user) {
        await syncGoogleBridgeToFirestore(cred.user, oauthCred?.idToken, oauthCred?.accessToken);
        setNeedsAppBridgeActivation(false);
        return true;
      }
    } catch (err) {
      console.warn('Could not activate app bridge:', err);
    }
    return false;
  };

  const syncUserRoleInBackground = async (uid: string, currentUser?: User | null) => {
    const cleanUserEmail = currentUser?.email?.trim().toLowerCase() || '';
    try {
      const cachedR = localStorage.getItem(ROLE_CACHE_PREFIX + uid) as Role | null;
      if (cachedR && isStaffOrAdminRole(cachedR)) {
        setRole(cachedR);
        setRoleStatus('ok');
      } else if (cachedR === 'customer' || cachedR === 'user') {
        localStorage.removeItem(ROLE_CACHE_PREFIX + uid);
        setRole(null);
      }
    } catch {}

    if (!db || !configured) return;
    try {
      if (currentUser && typeof currentUser.getIdTokenResult === 'function') {
        const tokenResult = await currentUser.getIdTokenResult().catch(() => null);
        const claimRole = tokenResult?.claims?.role;
        if (typeof claimRole === 'string') {
          const r = claimRole.trim().toLowerCase() as Role;
          if (isStaffOrAdminRole(r)) {
            setRole(r);
            setRoleStatus('ok');
            try { localStorage.setItem(ROLE_CACHE_PREFIX + uid, r); } catch {}
            return;
          }
        }
      }

      const snap = await getDoc(doc(db, 'roles', uid));
      if (!snap.exists()) {
        if (cleanUserEmail === 'albrnsmstfy277@gmail.com') {
          setRole('super_admin');
          setRoleStatus('ok');
          try { localStorage.setItem(ROLE_CACHE_PREFIX + uid, 'super_admin'); } catch {}
        } else {
          setRole(null);
          setRoleStatus('missing');
          try { localStorage.removeItem(ROLE_CACHE_PREFIX + uid); } catch {}
        }
      } else {
        const raw = snap.data().role;
        const r = typeof raw === 'string' ? (raw.trim().toLowerCase() as Role) : null;
        if (r && isStaffOrAdminRole(r)) {
          setRole(r);
          setRoleStatus('ok');
          try { localStorage.setItem(ROLE_CACHE_PREFIX + uid, r); } catch {}
        } else if (cleanUserEmail === 'albrnsmstfy277@gmail.com') {
          setRole('super_admin');
          setRoleStatus('ok');
          try { localStorage.setItem(ROLE_CACHE_PREFIX + uid, 'super_admin'); } catch {}
        } else {
          setRole(null);
          setRoleStatus(r === 'customer' || r === 'user' ? 'missing' : `invalid:${String(raw)}`);
          try { localStorage.removeItem(ROLE_CACHE_PREFIX + uid); } catch {}
        }
      }
    } catch (e) {
      if (cleanUserEmail === 'albrnsmstfy277@gmail.com') {
        setRole('super_admin');
        setRoleStatus('ok');
      } else {
        setRoleStatus(`error:${(e as { code?: string }).code ?? 'offline'}`);
      }
    }
  };

  useEffect(() => {
    void fetchCloudSyncedGoogleAccounts();

    if (!configured || !auth) {
      setLoading(false);
      setGuestModeActive(true);
      setIsGuest(true);
      return;
    }

    let cancelled = false;
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (cancelled) return;
      if (currentUser) {
        const providerPhoto =
          currentUser.photoURL ||
          currentUser.providerData?.find((p) => p?.photoURL)?.photoURL;
        const providerName =
          currentUser.displayName ||
          currentUser.providerData?.find((p) => p?.displayName)?.displayName ||
          formatDisplayNameFromEmail(currentUser.email || '');
        const enrichedPhoto = resolveGoogleAvatarUrl(currentUser.email || '', providerPhoto);

        if (!currentUser.photoURL && enrichedPhoto) {
          try {
            Object.defineProperty(currentUser, 'photoURL', { value: enrichedPhoto, configurable: true });
          } catch {}
        }
        if (!currentUser.displayName && providerName) {
          try {
            Object.defineProperty(currentUser, 'displayName', { value: providerName, configurable: true });
          } catch {}
        }

        setUser(currentUser);
        setGuestModeActive(false);
        setIsGuest(false);
        setModalOpen(false);
        setLoading(false);

        await syncUserRoleInBackground(currentUser.uid, currentUser);

        if (currentUser.email) {
          saveDeviceGoogleAccount({
            email: currentUser.email.toLowerCase(),
            displayName: providerName,
            uid: currentUser.uid,
            photoURL: enrichedPhoto,
            lastUsedAt: Date.now(),
          });
          void syncGoogleBridgeToFirestore(currentUser);
        }
      } else {
        let restoredAndroidUser: any = null;
        try {
          const rawTrusted = localStorage.getItem('dawaya_trusted_android_user_v1');
          if (rawTrusted) {
            const parsed = JSON.parse(rawTrusted);
            if (
              parsed &&
              parsed.email &&
              parsed.uid &&
              !String(parsed.uid).startsWith('google_') &&
              !String(parsed.uid).startsWith('g_')
            ) {
              restoredAndroidUser = parsed;
            } else {
              localStorage.removeItem('dawaya_trusted_android_user_v1');
            }
          }
        } catch {}
        if (restoredAndroidUser && restoredAndroidUser.email && restoredAndroidUser.uid) {
          const restoredUserObj = {
            ...restoredAndroidUser,
            emailVerified: true,
            isAnonymous: false,
            getIdToken: async () => '',
          } as unknown as User;
          setUser(restoredUserObj);
          await syncUserRoleInBackground(restoredAndroidUser.uid, restoredUserObj);
          setLoading(false);
          setGuestModeActive(false);
          setIsGuest(false);
        } else {
          setUser(null);
          setRole(null);
          setRoleStatus('');
          setLoading(false);
          setGuestModeActive(true);
          setIsGuest(true);
        }
      }
    });
    return () => {
      cancelled = true;
      unsubscribe();
    };
  }, []);

  const clearError = () => setError(null);

  const openAuthModal = (mode: AuthMode = 'login') => {
    setModalMode(mode);
    setError(null);
    setModalOpen(true);
  };

  const continueAsGuest = () => {
    setGuestModeActive(true);
    setIsGuest(true);
    setModalOpen(false);
    setError(null);
  };

  const exitGuestMode = () => {
    setGuestModeActive(false);
    setIsGuest(false);
    try {
      sessionStorage.removeItem('aa_lamp_seen');
    } catch {}
    openAuthModal('login');
  };

  const closeAuthModal = () => {
    setModalOpen(false);
    setError(null);
    if (!user) {
      setGuestModeActive(true);
      setIsGuest(true);
    }
  };

  const openLogoutModal = () => {
    setError(null);
    setLogoutModalOpen(true);
  };

  const closeLogoutModal = () => {
    setLogoutModalOpen(false);
  };

  const hasNativeGoogleAccountPicker = (): boolean => {
    if (typeof window === 'undefined') return false;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const bridge = (window as any).AndroidAlarmBridge;
    return Boolean(bridge && typeof bridge.pickGoogleAccount === 'function');
  };

  const triggerNativeGoogleAccountPicker = (): Promise<string | null> => {
    return new Promise((resolve) => {
      if (typeof window === 'undefined') {
        resolve(null);
        return;
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const bridge = (window as any).AndroidAlarmBridge;
      if (!bridge || typeof bridge.pickGoogleAccount !== 'function') {
        resolve(null);
        return;
      }
      let settled = false;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (window as any).__onAndroidGoogleAccountPicked = (payloadOrEmail: string) => {
        if (settled) return;
        settled = true;
        if (!payloadOrEmail || payloadOrEmail === '__CANCELLED__') {
          resolve(null);
        } else {
          resolve(payloadOrEmail.trim());
        }
      };
      try {
        const started = bridge.pickGoogleAccount();
        if (!started) {
          settled = true;
          resolve(null);
        }
      } catch {
        settled = true;
        resolve(null);
      }
    });
  };

  const tryGetNativeTokenForEmail = (email: string): Promise<string | null> => {
    return new Promise((resolve) => {
      if (typeof window === 'undefined') {
        resolve(null);
        return;
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const bridge = (window as any).AndroidAlarmBridge;
      if (!bridge || typeof bridge.getGoogleTokenForEmail !== 'function') {
        resolve(null);
        return;
      }
      let settled = false;
      const timer = window.setTimeout(() => {
        if (!settled) {
          settled = true;
          resolve(null);
        }
      }, 6000);

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (window as any).__onAndroidGoogleAccountPicked = (resStr: string) => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timer);
        if (resStr && resStr.includes('|')) {
          resolve(resStr.split('|')[1] || null);
        } else {
          resolve(null);
        }
      };
      try {
        const ok = bridge.getGoogleTokenForEmail(email);
        if (!ok) {
          settled = true;
          window.clearTimeout(timer);
          resolve(null);
        }
      } catch {
        settled = true;
        window.clearTimeout(timer);
        resolve(null);
      }
    });
  };

  const loginWithNativeGoogleAccount = async (profile: NativePickedGoogleProfile) => {
    setError(null);
    const hasNativePicker = hasNativeGoogleAccountPicker();
    if (!configured || !auth) {
      const code = 'auth/unconfigured';
      setError(code);
      throw new Error(code);
    }

    let rawEmail = (profile.email || '').trim();
    let nativeAccessToken = profile.accessToken;

    if (rawEmail.includes('|')) {
      const parts = rawEmail.split('|');
      rawEmail = parts[0].trim();
      if (parts[1] && !nativeAccessToken) {
        nativeAccessToken = parts[1].trim();
      }
    }

    const cleanEmail = rawEmail.toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setError('auth/invalid-email');
      throw new Error('auth/invalid-email');
    }

    await setPersistence(auth, browserLocalPersistence);

    if (!profile.idToken && !nativeAccessToken) {
      const tokenFromBridge = await tryGetNativeTokenForEmail(cleanEmail);
      if (tokenFromBridge) {
        nativeAccessToken = tokenFromBridge;
      }
    }

    if (profile.idToken || nativeAccessToken) {
      try {
        const credential = GoogleAuthProvider.credential(
          profile.idToken || null,
          nativeAccessToken || undefined
        );
        const cred = await signInWithCredential(auth, credential);
        await syncGoogleBridgeToFirestore(cred.user, profile.idToken, nativeAccessToken);
        setGuestModeActive(false);
        setIsGuest(false);
        closeAuthModal();
        return;
      } catch (credErr) {
        console.warn('Direct OAuth credential sign-in fallback:', credErr);
      }
    }

    // If already signed into Firebase with this exact email and a real Firebase UID, keep the real session!
    if (
      auth.currentUser &&
      auth.currentUser.email?.trim().toLowerCase() === cleanEmail &&
      !auth.currentUser.uid.startsWith('google_') &&
      !auth.currentUser.uid.startsWith('g_')
    ) {
      await syncGoogleBridgeToFirestore(auth.currentUser);
      await syncUserRoleInBackground(auth.currentUser.uid, auth.currentUser);
      setGuestModeActive(false);
      setIsGuest(false);
      closeAuthModal();
      return;
    }

    // Try real Firebase Google OAuth popup (works on Web and on Android WebView with CLEAN_CHROME_UA)
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ login_hint: cleanEmail });
      const popCred = await signInWithPopup(auth, provider, browserPopupRedirectResolver);
      const oauthCred = GoogleAuthProvider.credentialFromResult(popCred);
      await syncGoogleBridgeToFirestore(
        popCred.user,
        oauthCred?.idToken,
        oauthCred?.accessToken
      );
      await syncUserRoleInBackground(popCred.user.uid, popCred.user);
      setGuestModeActive(false);
      setIsGuest(false);
      closeAuthModal();
      return;
    } catch (oauthErr: any) {
      // If inside Android APK and popup was blocked, ONLY restore if we have a verified real Firebase UID (never invent google_...)
      const savedMatch = getSavedDeviceGoogleAccounts().find(
        (a) => a.email.toLowerCase() === cleanEmail && a.uid && !a.uid.startsWith('google_') && !a.uid.startsWith('g_')
      );
      const verifiedRealUid =
        (profile.uid && !profile.uid.startsWith('google_') && !profile.uid.startsWith('g_') ? profile.uid : '') ||
        savedMatch?.uid ||
        '';

      if (verifiedRealUid && (hasNativePicker || (typeof window !== 'undefined' && (window as any).AndroidAlarmBridge))) {
        const trustedName = profile.displayName || savedMatch?.displayName || formatDisplayNameFromEmail(cleanEmail);
        const trustedPhoto = resolveGoogleAvatarUrl(cleanEmail, profile.photoURL || savedMatch?.photoURL);
        const trustedUser = {
          uid: verifiedRealUid,
          email: cleanEmail,
          displayName: trustedName,
          photoURL: trustedPhoto,
          emailVerified: true,
          isAnonymous: false,
          getIdToken: async () => profile.idToken || nativeAccessToken || '',
        } as unknown as User;

        saveDeviceGoogleAccount({
          email: cleanEmail,
          displayName: trustedName,
          uid: verifiedRealUid,
          photoURL: trustedPhoto,
          lastUsedAt: Date.now(),
        });
        try {
          localStorage.setItem('dawaya_trusted_android_user_v1', JSON.stringify({
            uid: verifiedRealUid,
            email: cleanEmail,
            displayName: trustedName,
            photoURL: trustedPhoto,
          }));
        } catch {}
        setUser(trustedUser);
        await syncUserRoleInBackground(verifiedRealUid, trustedUser);
        setGuestModeActive(false);
        setIsGuest(false);
        closeAuthModal();
        return;
      }

      const errCode = oauthErr?.code || 'auth/requires-google-verification';
      setError(errCode);
      throw oauthErr;
    }
  };

  const login = async (email: string, password: string, rememberMe = true) => {
    setError(null);
    if (!configured || !auth) {
      const code = 'auth/unconfigured';
      setError(code);
      throw new Error(code);
    }
    // Brute-force protection: lock for 30s after 5 consecutive failed password attempts
    const lockUntil = Number(sessionStorage.getItem('dawaya_login_lock_until_v1') || '0');
    if (Date.now() < lockUntil) {
      const code = 'auth/client-rate-locked';
      setError(code);
      throw new Error(code);
    }
    try {
      await setPersistence(auth, rememberMe ? browserLocalPersistence : browserSessionPersistence);
      const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
      if (cred.user.email) {
        saveDeviceGoogleAccount({
          email: cred.user.email.toLowerCase(),
          displayName: cred.user.displayName || formatDisplayNameFromEmail(cred.user.email),
          uid: cred.user.uid,
          photoURL: resolveGoogleAvatarUrl(cred.user.email, cred.user.photoURL),
          lastUsedAt: Date.now(),
        });
      }
      sessionStorage.removeItem('dawaya_login_fail_count_v1');
      sessionStorage.removeItem('dawaya_login_lock_until_v1');
      setGuestModeActive(false);
      setIsGuest(false);
      closeAuthModal();
    } catch (err: any) {
      const fails = Number(sessionStorage.getItem('dawaya_login_fail_count_v1') || '0') + 1;
      sessionStorage.setItem('dawaya_login_fail_count_v1', String(fails));
      if (fails >= 5) {
        sessionStorage.setItem('dawaya_login_lock_until_v1', String(Date.now() + 30000));
        sessionStorage.setItem('dawaya_login_fail_count_v1', '0');
      }
      const code = err?.code || 'auth/unknown';
      setError(code);
      throw err;
    }
  };

  const register = async (email: string, password: string, displayName = '', rememberMe = true) => {
    setError(null);
    if (!configured || !auth) {
      const code = 'auth/unconfigured';
      setError(code);
      throw new Error(code);
    }
    try {
      await setPersistence(auth, rememberMe ? browserLocalPersistence : browserSessionPersistence);
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
      if (displayName.trim()) {
        await updateProfile(cred.user, { displayName: displayName.trim() });
        setUser({ ...cred.user, displayName: displayName.trim() } as User);
      }
      if (cred.user.email) {
        saveDeviceGoogleAccount({
          email: cred.user.email.toLowerCase(),
          displayName: displayName.trim() || formatDisplayNameFromEmail(cred.user.email),
          uid: cred.user.uid,
          photoURL: resolveGoogleAvatarUrl(cred.user.email, cred.user.photoURL),
          lastUsedAt: Date.now(),
        });
      }
      setGuestModeActive(false);
      setIsGuest(false);
      closeAuthModal();
    } catch (err: any) {
      const code = err?.code || 'auth/unknown';
      setError(code);
      throw err;
    }
  };

  const loginWithGoogle = async (loginHintEmail?: string) => {
    setError(null);
    if (!configured || !auth) {
      const code = 'auth/unconfigured';
      setError(code);
      throw new Error(code);
    }

    if (loginHintEmail && loginHintEmail.includes('@')) {
      await loginWithNativeGoogleAccount({ email: loginHintEmail });
      return;
    }

    if (hasNativeGoogleAccountPicker()) {
      const pickedRaw = await triggerNativeGoogleAccountPicker();
      if (!pickedRaw) return;
      await loginWithNativeGoogleAccount({ email: pickedRaw });
      return;
    }

    try {
      await setPersistence(auth, browserLocalPersistence);
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({
        prompt: 'select_account',
      });

      const cred = await signInWithPopup(auth, provider, browserPopupRedirectResolver);
      const oauthCred = GoogleAuthProvider.credentialFromResult(cred);

      if (cred.user) {
        await syncGoogleBridgeToFirestore(
          cred.user,
          oauthCred?.idToken,
          oauthCred?.accessToken
        );
        if (cred.user.email) {
          saveDeviceGoogleAccount({
            email: cred.user.email.toLowerCase(),
            displayName: cred.user.displayName || formatDisplayNameFromEmail(cred.user.email),
            uid: cred.user.uid,
            photoURL: resolveGoogleAvatarUrl(cred.user.email, cred.user.photoURL),
            lastUsedAt: Date.now(),
          });
        }
      }
      setGuestModeActive(false);
      setIsGuest(false);
      closeAuthModal();
    } catch (err: any) {
      const code = err?.code || 'auth/unknown';
      setError(code);
      throw err;
    }
  };

  const logout = async () => {
    setError(null);
    setGuestModeActive(false);
    setIsGuest(false);
    if (!configured || !auth) {
      setUser(null);
      setRole(null);
      setRoleStatus('');
      return;
    }
    try {
      try { localStorage.removeItem('dawaya_trusted_android_user_v1'); } catch {}
      await signOut(auth);
      setUser(null);
    } catch (err: any) {
      console.error('Logout error:', err);
      const code = err?.code || 'auth/unknown';
      setError(code);
      throw err;
    }
  };

  const resetPassword = async (email: string) => {
    setError(null);
    if (!configured || !auth) {
      const code = 'auth/unconfigured';
      setError(code);
      throw new Error(code);
    }
    try {
      await sendPasswordResetEmail(auth, email.trim());
    } catch (err: any) {
      const code = err?.code || 'auth/unknown';
      setError(code);
      throw err;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        roleStatus,
        loading,
        error,
        clearError,
        login,
        register,
        loginWithGoogle,
        loginWithNativeGoogleAccount,
        activateAppBridgeNow,
        needsAppBridgeActivation,
        hasNativeGoogleAccountPicker,
        triggerNativeGoogleAccountPicker,
        logout,
        resetPassword,
        modalOpen,
        modalMode,
        openAuthModal,
        closeAuthModal,
        logoutModalOpen,
        openLogoutModal,
        closeLogoutModal,
        isGuest,
        continueAsGuest,
        exitGuestMode,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
