import { useEffect, useState } from 'react';
import { fetchDrugImageByBarcode, fetchDrugImageFromWikipedia, getCachedDrugImageUrl, loadDawayaImageMap } from './dawayaDrugDatabaseService';
import React from 'react';

export interface VectorIconProps {
  size?: number;
  color?: string;
  accentColor?: string;
  className?: string;
}

/**
 * Custom Medical & Navigation Vector SVG Icon Suite for DAWAYA | دوايا
 * Designed specifically for the Deep Navy (#0D1F38), Warm Sage-Gold (#CFD29D),
 * and Emerald Green (#138866) brand identity.
 */
export function NavHomeVectorIcon({ size = 24, color = 'currentColor' }: VectorIconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M3.6 10.4L11.1 3.8C11.62 3.35 12.38 3.35 12.9 3.8L20.4 10.4C20.78 10.74 21 11.22 21 11.73V19.2C21 20.19 20.19 21 19.2 21H14.8V15.4C14.8 14.63 14.17 14 13.4 14H10.6C9.83 14 9.2 14.63 9.2 15.4V21H4.8C3.81 21 3 20.19 3 19.2V11.73C3 11.22 3.22 10.74 3.6 10.4Z"
        fill={color}
      />
    </svg>
  );
}

export function NavDashboardVectorIcon({ size = 24, color = 'currentColor' }: VectorIconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <rect x="3" y="3" width="18" height="18" rx="3.5" fill={color} fillOpacity="0.92" />
      <rect x="6.5" y="10" width="2.4" height="7.5" rx="1" fill="#0D1F38" />
      <rect x="10.8" y="12.5" width="2.4" height="5" rx="1" fill="#0D1F38" />
      <rect x="15.1" y="7" width="2.4" height="10.5" rx="1" fill="#0D1F38" />
    </svg>
  );
}

export function NavCapsuleVectorIcon({ size = 24, color = 'currentColor' }: VectorIconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <g transform="rotate(-45 12 12)">
        <rect x="4" y="7.5" width="16" height="9" rx="4.5" stroke={color} strokeWidth="2" />
        <path d="M12 7.5H15.5C17.9853 7.5 20 9.51472 20 12C20 14.4853 17.9853 16.5 15.5 16.5H12V7.5Z" fill={color} />
      </g>
    </svg>
  );
}

export function NavRadarVectorIcon({ size = 24, color = 'currentColor', accentColor = '#138866' }: VectorIconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="9" stroke={color} strokeWidth="1.9" />
      <circle cx="12" cy="12" r="5.4" stroke={color} strokeWidth="1.7" strokeOpacity="0.85" />
      <circle cx="12" cy="12" r="2" fill={color} />
      <path d="M12 12L17.8 6.2" stroke={color} strokeWidth="1.9" strokeLinecap="round" />
      <circle cx="15.2" cy="14.8" r="1.8" fill={accentColor} />
    </svg>
  );
}

export function NavShieldSafetyVectorIcon({ size = 24, color = 'currentColor' }: VectorIconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M12 3L4.5 6.2V11.6C4.5 16.45 7.68 20.88 12 22C16.32 20.88 19.5 16.45 19.5 11.6V6.2L12 3Z"
        stroke={color}
        strokeWidth="1.9"
        fill={color}
        fillOpacity="0.14"
      />
      <path d="M9.2 12.2L11.1 14.1L15.2 10" stroke={color} strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function NavLeafCareVectorIcon({ size = 24, color = 'currentColor' }: VectorIconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M19.5 4.5C12.5 4.5 6 8.2 6 15.2C6 17.3 7.7 19 9.8 19C16.8 19 20.5 12.5 19.5 4.5Z"
        stroke={color}
        strokeWidth="1.9"
        fill={color}
        fillOpacity="0.15"
      />
      <path d="M6 19L14.5 10.5" stroke={color} strokeWidth="1.9" strokeLinecap="round" />
    </svg>
  );
}

export function NavAiSimVectorIcon({ size = 24, color = 'currentColor' }: VectorIconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <rect x="4" y="6" width="16" height="12" rx="4" stroke={color} strokeWidth="1.9" fill={color} fillOpacity="0.14" />
      <circle cx="9.2" cy="12" r="1.5" fill={color} />
      <circle cx="14.8" cy="12" r="1.5" fill={color} />
      <path d="M12 3V6M8 3H16" stroke={color} strokeWidth="1.9" strokeLinecap="round" />
    </svg>
  );
}

export function NavBookSourcesVectorIcon({ size = 24, color = 'currentColor' }: VectorIconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M4 5.5C4 4.4 4.9 3.5 6 3.5H11.2C12.2 3.5 13 4.3 13 5.3V19.5C13 18.7 12.3 18 11.5 18H6C4.9 18 4 17.1 4 16V5.5Z"
        stroke={color}
        strokeWidth="1.8"
        fill={color}
        fillOpacity="0.14"
      />
      <path
        d="M20 5.5C20 4.4 19.1 3.5 18 3.5H12.8C11.8 3.5 11 4.3 11 5.3V19.5C11 18.7 11.7 18 12.5 18H18C19.1 18 20 17.1 20 16V5.5Z"
        stroke={color}
        strokeWidth="1.8"
      />
    </svg>
  );
}

export function CapsuleGlobeLangIcon({ code = 'AR', size = 28 }: { code?: string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 28 28" fill="none" aria-hidden="true">
      <circle cx="14" cy="14" r="11.5" stroke="#E2E8F0" strokeWidth="1.75" />
      <path d="M3 10.2H25M3 17.8H25" stroke="#E2E8F0" strokeWidth="1.4" strokeOpacity="0.85" />
      <path
        d="M14 2.5C16.9 5.6 18.4 9.6 18.4 14C18.4 18.4 16.9 22.4 14 25.5C11.1 22.4 9.6 18.4 9.6 14C9.6 9.6 11.1 5.6 14 2.5Z"
        stroke="#E2E8F0"
        strokeWidth="1.4"
        strokeOpacity="0.85"
      />
      <rect x="4.2" y="9.4" width="19.6" height="9.2" rx="4.6" fill="#0D1F38" stroke="#CFD29D" strokeWidth="1.2" />
      <text
        x="14"
        y="15.8"
        textAnchor="middle"
        fill="#FFFFFF"
        fontSize="7.8"
        fontWeight="800"
        fontFamily="system-ui, -apple-system, sans-serif"
      >
        {code.toUpperCase()}
      </text>
    </svg>
  );
}

export function CapsuleMoonIcon({ isDark = true, size = 22 }: { isDark?: boolean; size?: number }) {
  if (!isDark) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <circle cx="12" cy="12" r="4.6" fill="#CFD29D" />
        <path
          d="M12 2.5V5M12 19V21.5M2.5 12H5M19 12H21.5M5.3 5.3L7.1 7.1M16.9 16.9L18.7 18.7M18.7 5.3L16.9 7.1M7.1 16.9L5.3 18.7"
          stroke="#CFD29D"
          strokeWidth="2"
          strokeLinecap="round"
        />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M20.2 14.6C19.1 15.1 17.8 15.4 16.5 15.4C11.5 15.4 7.5 11.4 7.5 6.4C7.5 5.1 7.8 3.8 8.3 2.7C4.8 4.1 2.4 7.5 2.4 11.5C2.4 16.8 6.7 21.1 12 21.1C16 21.1 19.4 18.7 20.2 14.6Z"
        fill="#E2E8F0"
      />
    </svg>
  );
}

export function CapsuleSignOutIcon({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M14 4H7.2C5.98 4 5 4.98 5 6.2V17.8C5 19.02 5.98 20 7.2 20H14"
        stroke="#E2E8F0"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <path
        d="M10 12H20M20 12L16.5 8.5M20 12L16.5 15.5"
        stroke="#CFD29D"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function CapsuleUserGuestIcon({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="8.5" r="3.8" fill="#CFD29D" />
      <path
        d="M5.2 19.4C5.9 15.9 8.6 13.8 12 13.8C15.4 13.8 18.1 15.9 18.8 19.4"
        stroke="#CFD29D"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
    </svg>
  );
}

/**
 * Renders a crisp vector icon for any clinical tool key or dosage form
 */
export function DosageFormVectorBadge({ form, size = 20 }: { form?: string; size?: number }) {
  const f = (form || 'tablet').toLowerCase();
  if (f.includes('capsule')) {
    return <NavCapsuleVectorIcon size={size} color="#138866" />;
  }
  if (f.includes('syrup') || f.includes('suspension') || f.includes('solution') || f.includes('drops')) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="8.5" y="3" width="7" height="3.2" rx="1" stroke="#138866" strokeWidth="1.8" />
        <path
          d="M7 9.5C7 7.8 8.3 6.2 10 6.2H14C15.7 6.2 17 7.8 17 9.5V18.8C17 20 16 21 14.8 21H9.2C8 21 7 20 7 18.8V9.5Z"
          stroke="#138866"
          strokeWidth="1.8"
          fill="#138866"
          fillOpacity="0.12"
        />
        <path d="M9.5 13.5H14.5M12 11V16" stroke="#0D1F38" strokeWidth="1.8" strokeLinecap="round" />
      </svg>
    );
  }
  if (f.includes('ampoule') || f.includes('vial') || f.includes('infusion') || f.includes('injection')) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M18 3L21 6M14.5 6.5L17.5 9.5M6 15L14.5 6.5L17.5 9.5L9 18H6V15Z" stroke="#138866" strokeWidth="1.8" fill="#138866" fillOpacity="0.14" />
        <path d="M3 21L6 18" stroke="#0D1F38" strokeWidth="1.8" strokeLinecap="round" />
      </svg>
    );
  }
  if (f.includes('cream') || f.includes('ointment') || f.includes('topical')) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M7 5H17L15.5 17.5C15.4 18.4 14.6 19 13.7 19H10.3C9.4 19 8.6 18.4 8.5 17.5L7 5Z" stroke="#138866" strokeWidth="1.8" fill="#138866" fillOpacity="0.12" />
        <rect x="9.5" y="19" width="5" height="2.5" rx="0.8" fill="#0D1F38" />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="8" stroke="#138866" strokeWidth="1.8" fill="#138866" fillOpacity="0.12" />
      <path d="M7.5 16.5L16.5 7.5" stroke="#0D1F38" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );
}


export function HeroSearchVectorIcon({ size = 20, color = '#138866' }: VectorIconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="11" cy="11" r="7" stroke={color} strokeWidth="2.2" fill={color} fillOpacity="0.1" />
      <path d="M16.2 16.2L20.5 20.5" stroke={color} strokeWidth="2.2" strokeLinecap="round" />
    </svg>
  );
}

export function HeroMicVectorIcon({ size = 19, color = 'currentColor' }: VectorIconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <rect x="9" y="3" width="6" height="11" rx="3" stroke={color} strokeWidth="1.9" fill={color} fillOpacity="0.16" />
      <path d="M5.5 11C5.5 14.59 8.41 17.5 12 17.5C15.59 17.5 18.5 14.59 18.5 11M12 17.5V21M8.5 21H15.5" stroke={color} strokeWidth="1.9" strokeLinecap="round" />
    </svg>
  );
}

export function HeroScannerVectorIcon({ size = 20, color = 'currentColor' }: VectorIconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M4 8V6C4 4.9 4.9 4 6 4H8M16 4H18C19.1 4 20 4.9 20 6V8M20 16V18C20 19.1 19.1 20 18 20H16M8 20H6C4.9 20 4 19.1 4 18V16" stroke={color} strokeWidth="2" strokeLinecap="round" />
      <circle cx="12" cy="12" r="3.2" stroke={color} strokeWidth="1.9" fill={color} fillOpacity="0.18" />
    </svg>
  );
}

/**
 * Universal Duotone Medical SVG Vector Icon resolver for all 25+ DAWAYA routes and tools
 */
export function DawayaRouteVectorIcon({
  route,
  size = 22,
  color = 'currentColor',
}: {
  route: string;
  size?: number;
  color?: string;
}) {
  const r = (route || '').toLowerCase();

  if (r === '/' || r === 'home') {
    return <NavHomeVectorIcon size={size} color={color} />;
  }
  if (r.includes('patient-dashboard') || r.includes('research')) {
    return <NavDashboardVectorIcon size={size} color={color} />;
  }
  if (r.includes('medicines') || r.includes('drug-directory')) {
    return <NavCapsuleVectorIcon size={size} color={color} />;
  }
  if (r.includes('prescription-radar')) {
    return <NavRadarVectorIcon size={size} color={color} accentColor="#138866" />;
  }
  if (r.includes('passport') || r.includes('health-profile')) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="3" y="5" width="18" height="14" rx="3" stroke={color} strokeWidth="1.9" fill={color} fillOpacity="0.12" />
        <circle cx="8.5" cy="11" r="2.2" fill={color} />
        <path d="M5.5 16C6.1 14.3 7.2 13.5 8.5 13.5C9.8 13.5 10.9 14.3 11.5 16" stroke={color} strokeWidth="1.7" strokeLinecap="round" />
        <path d="M14 9.5H18M14 13H17" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
      </svg>
    );
  }
  if (r.includes('complete-checkup') || r.includes('interactions')) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M13 2.5L4.5 13.5H11.5L10.5 21.5L19.5 10.5H12.5L13 2.5Z" stroke={color} strokeWidth="1.9" strokeLinejoin="round" fill={color} fillOpacity="0.16" />
      </svg>
    );
  }
  if (r.includes('cost-saver')) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M12.5 3H6C4.34 3 3 4.34 3 6V12.5C3 13.3 3.32 14.06 3.88 14.62L10.38 21.12C11.55 22.29 13.45 22.29 14.62 21.12L21.12 14.62C22.29 13.45 22.29 11.55 21.12 10.38L14.62 3.88C14.06 3.32 13.3 3 12.5 3Z" stroke={color} strokeWidth="1.9" fill={color} fillOpacity="0.14" />
        <circle cx="7.8" cy="7.8" r="1.6" fill={color} />
      </svg>
    );
  }
  if (r.includes('pediatric-helper') || r === 'mother') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <circle cx="12" cy="12" r="8.5" stroke={color} strokeWidth="1.9" fill={color} fillOpacity="0.12" />
        <circle cx="9.3" cy="10.8" r="1.2" fill={color} />
        <circle cx="14.7" cy="10.8" r="1.2" fill={color} />
        <path d="M9.2 14.6C10 15.8 11 16.3 12 16.3C13 16.3 14 15.8 14.8 14.6" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
        <path d="M12 3.5C13.4 3.5 14.2 4.6 13.5 5.8C12.9 6.8 11.2 6.8 11.2 5.6" stroke={color} strokeWidth="1.7" strokeLinecap="round" />
      </svg>
    );
  }
  if (r.includes('green-prescription') || r.includes('treatment-care') || r.includes('safe-disposal')) {
    return <NavLeafCareVectorIcon size={size} color={color} />;
  }
  if (r.includes('allergy-checker') || r.includes('clinical-safety') || r === 'patient') {
    return <NavShieldSafetyVectorIcon size={size} color={color} />;
  }
  if (r.includes('daily-schedule') || r.includes('tracker')) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="3.5" y="5" width="17" height="15.5" rx="3" stroke={color} strokeWidth="1.9" fill={color} fillOpacity="0.12" />
        <path d="M8 3V6.5M16 3V6.5M3.5 9.5H20.5" stroke={color} strokeWidth="1.9" strokeLinecap="round" />
        <circle cx="12" cy="15" r="2.8" stroke={color} strokeWidth="1.7" />
      </svg>
    );
  }
  if (r.includes('compare')) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M12 3V21M5 7H19M5 7L2.5 13.5H7.5L5 7ZM19 7L16.5 13.5H21.5L19 7Z" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }
  if (r.includes('cold-shot') || r.includes('side-effects')) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M18 3L21 6M14.5 6.5L17.5 9.5M6 15L14.5 6.5L17.5 9.5L9 18H6V15Z" stroke={color} strokeWidth="1.9" fill={color} fillOpacity="0.15" />
        <path d="M3 21L6 18" stroke={color} strokeWidth="1.9" strokeLinecap="round" />
      </svg>
    );
  }
  if (r.includes('scan')) {
    return <HeroScannerVectorIcon size={size} color={color} />;
  }
  if (r.includes('games') || r.includes('interactive-sim') || r.includes('assistant')) {
    return <NavAiSimVectorIcon size={size} color={color} />;
  }
  if (r.includes('partners') || r === 'doctor') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="4" y="4" width="16" height="16" rx="3.5" stroke={color} strokeWidth="1.9" fill={color} fillOpacity="0.12" />
        <path d="M12 8V16M8 12H16" stroke={color} strokeWidth="2.2" strokeLinecap="round" />
      </svg>
    );
  }
  return <NavBookSourcesVectorIcon size={size} color={color} />;
}

/**
 * 3D High-Detail Realistic Medicine Packaging & Dosage Form Illustration
 * Matches the realistic 3D product box + pills/bottle mockup aesthetic.
 */
function getRealDosageFormPhotoUrl(form?: string): string {
  const f = (form || 'tablet').toLowerCase();
  if (/cream|oint|gel|lotion|wash|shampoo|topical|soap|toner|كريم|مرهم|جل|غسول|شامبو/.test(f)) {
    return 'https://www.cosmapay.com/storage/bepanthen-cream-800x800.webp';
  }
  if (/vial|amp|inj|infusion|حقن|أمبول|فيال/.test(f)) {
    return 'https://dkud4u09qff41.cloudfront.net/Products/8f940eb8-81d0-4e08-8730-18efc94f06f6.jpeg';
  }
  if (/drop|spray|eye|ear|nasal|نقط|قطرة|بخاخ/.test(f)) {
    return 'https://dkud4u09qff41.cloudfront.net/Products/42462444-f6f2-401b-9c40-8b358158e632.jpeg';
  }
  if (/syrup|susp|sol|شراب|معلق/.test(f)) {
    return 'https://upload.wikimedia.org/wikipedia/commons/e/e5/Cough_medicine.jpg';
  }
  if (/cap|softgel|كبسول/.test(f)) {
    return 'https://upload.wikimedia.org/wikipedia/commons/2/2f/Fish_Oil_Capsules.jpg';
  }
  return 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/Biogesic_branded_paracetamol_500mg_%28500_side%29.jpg/320px-Biogesic_branded_paracetamol_500mg_%28500_side%29.jpg';
}

export function Realistic3DMedicineThumb({
  form,
  size = 64,
  medId,
  brandNameEn,
  barcode,
  genericName,
}: {
  form?: string;
  size?: number;
  medId?: string;
  brandNameEn?: string;
  barcode?: string;
  genericName?: string;
}) {
  const [imgUrl, setImgUrl] = useState<string | null>(() =>
    getCachedDrugImageUrl(medId, brandNameEn, barcode, genericName)
  );
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    let alive = true;
    setImgFailed(false);
    const cached = getCachedDrugImageUrl(medId, brandNameEn, barcode, genericName);
    if (cached) {
      setImgUrl(cached);
      return;
    }
    setImgUrl(null);
    void loadDawayaImageMap().then(async () => {
      if (!alive) return;
      const afterMap = getCachedDrugImageUrl(medId, brandNameEn, barcode, genericName);
      if (afterMap) {
        setImgUrl(afterMap);
        return;
      }
      if (barcode && barcode.replace(/\D/g, '').length >= 8) {
        const fetchedBc = await fetchDrugImageByBarcode(barcode);
        if (alive && fetchedBc) {
          setImgUrl(fetchedBc);
          return;
        }
      }
      const fetchedWiki = await fetchDrugImageFromWikipedia(brandNameEn, genericName);
      if (alive && fetchedWiki) {
        setImgUrl(fetchedWiki);
      }
    });
    return () => {
      alive = false;
    };
  }, [medId, brandNameEn, barcode, genericName]);

  useEffect(() => {
    const onDbUpdate = () => {
      const updated = getCachedDrugImageUrl(medId, brandNameEn, barcode, genericName);
      if (updated) {
        setImgFailed(false);
        setImgUrl(updated);
      }
    };
    window.addEventListener('dawaya_db_updated', onDbUpdate);
    window.addEventListener('dawaya-full-db-updated', onDbUpdate);
    return () => {
      window.removeEventListener('dawaya_db_updated', onDbUpdate);
      window.removeEventListener('dawaya-full-db-updated', onDbUpdate);
    };
  }, [medId, brandNameEn, barcode, genericName]);

  const fallbackRealPhoto = getRealDosageFormPhotoUrl(form);
  const displaySrc = !imgFailed && imgUrl ? imgUrl : fallbackRealPhoto;

  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: 14,
        background: '#ffffff',
        border: '1px solid #e2e8f0',
        padding: 4,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
        overflow: 'hidden',
      }}
    >
      <img
        src={displaySrc}
        alt={brandNameEn || 'Medicine package'}
        loading="lazy"
        onError={() => {
          if (!imgFailed && imgUrl) {
            setImgFailed(true);
          }
        }}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'contain',
          borderRadius: 10,
          display: 'block',
        }}
      />
    </div>
  );
}


export function CleanUiIcon({
  name,
  size = 18,
  color = 'currentColor',
}: {
  name: string;
  size?: number;
  color?: string;
}) {
  const n = (name || '').toLowerCase();

  if (n === 'driver' || n === 'car' || n === 'driver_transport') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M14 16H9m10 0h3v-3.15a1 1 0 0 0-.84-.99L16 11l-2.7-3.6a1 1 0 0 0-.8-.4H5.24a2 2 0 0 0-1.8 1.1l-.8 1.63A6 6 0 0 0 2 12.42V16h2" />
        <circle cx="6.5" cy="16.5" r="2.5" />
        <circle cx="16.5" cy="16.5" r="2.5" />
      </svg>
    );
  }
  if (n === 'factory' || n === 'machinery' || n === 'machinery_factory') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z" />
        <path d="M17 18h1M12 18h1M7 18h1" />
      </svg>
    );
  }
  if (n === 'office' || n === 'laptop' || n === 'office_desk') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <rect x="3" y="4" width="18" height="12" rx="2" />
        <line x1="2" y1="20" x2="22" y2="20" />
      </svg>
    );
  }
  if (n === 'student' || n === 'academic') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
        <path d="M6 12v5c3 3 9 3 12 0v-5" />
      </svg>
    );
  }
  if (n === 'home' || n === 'homemaker') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
        <polyline points="9 22 9 12 15 12 15 22" />
      </svg>
    );
  }
  if (n === 'user' || n === 'male' || n === 'female' || n === 'profile') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
        <circle cx="12" cy="7" r="4" />
      </svg>
    );
  }
  if (n === 'water' || n === 'hydration' || n === 'droplet') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z" fill={color} fillOpacity="0.14" />
      </svg>
    );
  }
  if (n === 'check' || n === 'verified' || n === 'normal' || n === 'safe') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
        <polyline points="22 4 12 14.01 9 11.01" />
      </svg>
    );
  }
  if (n === 'alert' || n === 'warning' || n === 'danger' || n === 'impaired') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
        <line x1="12" y1="9" x2="12" y2="13" />
        <line x1="12" y1="17" x2="12.01" y2="17" />
      </svg>
    );
  }
  if (n === 'clock' || n === 'alarm' || n === 'time') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <circle cx="12" cy="12" r="10" />
        <polyline points="12 6 12 12 16 14" />
      </svg>
    );
  }
  if (n === 'phone' || n === 'call') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
      </svg>
    );
  }
  if (n === 'edit' || n === 'other') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
      </svg>
    );
  }
  if (n === 'shield' || n === 'general') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 8v4l3 3" />
    </svg>
  );
}
